# The Summit: automatic daily days

From now on you don't write days in the spreadsheet. Every evening Netlify asks Claude to write a
new day, checks it, and stores it. The game picks it up by itself.

## How it works

* `netlify/functions/build-day.mjs` runs every 10 minutes from 7pm to midnight (Melbourne time).
  Each run does one small job so it never hits Netlify's 30-second limit:
  1. plan the day (theme + 7 prompts, never repeating old prompts),
  2. write one pitch (answers, grades, false summits, gem, pun, clue, bonus stickers) and check it,
  3. once all 7 pitches pass, scramble the day and publish it.
  It always works on the first missing day between today and two days ahead, so every timezone
  has its climb ready before midnight. A pitch that keeps failing is swapped for a new prompt.
* Days are stored in **Netlify Blobs** (Netlify's built-in storage). No database needed.
* `netlify/functions/day.mjs` hands the game a day at `/api/day?n=12`. It refuses future days
  (unless you add `&key=basecamp`), so nobody can peek ahead.
* The game first looks in `site/days/` (your 11 hand-made days), then asks `/api/day`.

## One-time setup

1. **Get a Claude API key.** Go to console.anthropic.com, add a little credit (a few dollars lasts
   months: each day is about 8 short requests), then create an API key.
2. **Put the project on GitHub.** Create a free GitHub account, make a new *private* repository
   called `the-summit`, and use **Add file → Upload files** to drag in everything from this folder
   (`site`, `netlify`, `content`, `tools`, `netlify.toml`, `package.json`, the readme files).
3. **Connect Netlify to GitHub.** In your Netlify project: **Project configuration → Build & deploy
   → Link repository**, choose GitHub and the `the-summit` repo. Leave the build command empty;
   Netlify reads `netlify.toml` (publish folder `site`, functions folder `netlify/functions`).
4. **Add the secret key.** **Project configuration → Environment variables → Add a variable**:
   * `ANTHROPIC_API_KEY` = your key from step 1 (mark it secret)
   * optional `SUMMIT_LAUNCH` = your launch date, e.g. `2026-11-01` (must match `launch` in `site/index.html`)
5. **Deploy.** Netlify builds automatically. Under **Functions** you should see `build-day` with a
   **Scheduled** badge, and `day`.

From then on, any change you upload to GitHub goes live automatically. No more dragging zips.

## Testing it today

Your 11 hand-made days cover the next week or so, so the generator will sit quietly until it's
needed. To test straight away:

1. Add environment variable `SUMMIT_TEST_DAY` = `12`, then redeploy (**Deploys → Trigger deploy**).
2. In **Functions → build-day**, press **Run now** about 9 times, a minute or so apart
   (1 plan + 7 pitches + 1 publish). The function log shows each step.
3. Open `https://YOUR-SITE/?day=12&key=basecamp` and play the generated day.
4. Delete `SUMMIT_TEST_DAY` when you're happy.

## Optional settings (environment variables)

| Variable | What it does | Default |
|---|---|---|
| `SUMMIT_MODEL` | Which Claude model writes the days | `claude-haiku-4-5-20251001` (fast, cheap) |
| `SUMMIT_KEY`, `SUMMIT_SALT` | Scramble settings, must match `site/index.html` | the current values |
| `SUMMIT_PREVIEW_KEY` | The `&key=` for previewing future days | `basecamp` |

Themes rotate through the list at the top of `netlify/functions/lib/summit.mjs`. Edit it any time.
