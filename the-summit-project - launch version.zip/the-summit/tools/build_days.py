#!/usr/bin/env python3
"""
The Summit: day builder (Python version).

Reads content/The-Summit-Content.xlsx and writes one scrambled file per finished day
into site/days/. Run from the project folder:

    python3 tools/build_days.py

Needs:  pip install openpyxl
The browser version (tools/day-builder.html) does exactly the same thing with no install.
"""
import base64, json, os, sys
from openpyxl import load_workbook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BOOK = os.path.join(ROOT, 'content', 'The-Summit-Content.xlsx')
OUT = os.path.join(ROOT, 'site', 'days')

TIERS = {'tourist trail': 'common', 'scramble': 'uncommon', 'clean ascent': 'rare', 'overhang': 'veryrare',
         'free solo': 'ultra', 'first ascent': 'gem', 'false summit': 'false'}
CATS = {'sports fan': 'sport', 'star spotted': 'celeb', 'screen time': 'screen',
        'weird & wonderful': 'wild'}


def fnv(s):
    h = 0x811c9dc5
    for b in s.encode('utf-8'):
        h ^= b
        h = (h * 0x01000193) & 0xffffffff
    return format(h, '08x')


def file_for(n, salt):
    return f'{fnv(f"{n}:{salt}")}{fnv(f"{salt}:{n}")}.json'


def scramble(obj, key):
    raw = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    k = key.encode('utf-8')
    return base64.b64encode(bytes(b ^ k[i % len(k)] for i, b in enumerate(raw))).decode('ascii')


def text(v):
    return str(v).strip() if v is not None else ''


def build(book=BOOK, out=OUT, only=None):
    wb = load_workbook(book, data_only=True)
    settings = {text(r[0].value): r[1].value for r in wb['Settings'].iter_rows(min_row=2) if r[0].value}
    key, salt = text(settings['Scramble key']), text(settings['Scramble salt'])

    days = {int(r[0].value): text(r[2].value) for r in wb['Days'].iter_rows(min_row=2) if r[0].value and text(r[2].value)}
    prompts, answers = {}, {}
    for r in wb['Prompts'].iter_rows(min_row=2, values_only=True):
        if r[0] and r[1] and text(r[2]):
            prompts[(int(r[0]), int(r[1]))] = {'q': text(r[2]), 'joke': text(r[3]), 'clue': text(r[4])}
    for r in wb['Answers'].iter_rows(min_row=2, values_only=True):
        if r[0] and r[1] and text(r[2]):
            answers.setdefault((int(r[0]), int(r[1])), []).append(r)

    os.makedirs(out, exist_ok=True)
    built, problems = [], []
    for n, theme in sorted(days.items()):
        if only and n not in only:
            continue
        day = {'theme': theme, 'prompts': []}
        ok = True
        for pitch in range(1, 8):
            p = prompts.get((n, pitch))
            rows = answers.get((n, pitch), [])
            if not p or not rows:
                problems.append(f'Day {n} pitch {pitch}: missing prompt or answers'); ok = False; continue
            t, bonus = {}, {}
            for r in rows:
                tier = TIERS.get(text(r[4]).lower())
                if not tier:
                    problems.append(f'Day {n} pitch {pitch}: "{text(r[2])}" has no valid grade'); ok = False; continue
                names = [text(r[2])] + [a.strip() for a in text(r[3]).replace(',', '|').split('|') if a.strip()]
                t.setdefault(tier, []).append('|'.join(names))
                cat = CATS.get(text(r[5]).lower())
                if cat:
                    bonus[text(r[2]).lower()] = [cat, text(r[6])]
            if len(t.get('gem', [])) != 1:
                problems.append(f'Day {n} pitch {pitch}: needs exactly 1 First ascent'); ok = False
            if len(t.get('false', [])) != 3:
                problems.append(f'Day {n} pitch {pitch}: needs exactly 3 False summits'); ok = False
            if len(rows) < 50:
                problems.append(f'Day {n} pitch {pitch}: only {len(rows)} answers (aim for 50+)')
            day['prompts'].append({'q': p['q'], 'joke': p['joke'], 'clue': p['clue'],
                                   't': {k: ';'.join(v) for k, v in t.items()}, 'bonus': bonus})
        if not ok:
            problems.append(f'Day {n} NOT built')
            continue
        name = file_for(n, salt)
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            json.dump({'v': 1, 'd': scramble(day, key)}, f)
        built.append((n, theme, name))
    return built, problems


if __name__ == '__main__':
    only = {int(a) for a in sys.argv[1:]} or None
    built, problems = build(only=only)
    for n, theme, name in built:
        print(f'Built day {n:>3}  {theme:<24} -> site/days/{name}')
    for p in problems:
        print('  !', p)
    print(f'{len(built)} day file(s) written.')
