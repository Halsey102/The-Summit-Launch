// Serves a day's scrambled file to the game: /api/day?n=12
import { getStore } from '@netlify/blobs';
import { dayNumberUTC } from './lib/summit.mjs';

export const config = { path: '/api/day' };

export default async (req) => {
  const url = new URL(req.url), n = Number(url.searchParams.get('n'));
  const preview = url.searchParams.get('key') && url.searchParams.get('key') === (process.env.SUMMIT_PREVIEW_KEY || 'basecamp');
  // Never hand out days more than one ahead of UTC today (covers timezones ahead of UTC), unless previewing.
  if (!n || (!preview && n > dayNumberUTC() + 1)) return new Response('Not available', { status: 404 });
  const body = await getStore('summit').get(`day/${n}`);
  if (!body) return new Response('Not found', { status: 404 });
  return new Response(body, { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=300' } });
};
