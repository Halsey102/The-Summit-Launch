// Runs every 10 minutes in the evening (UTC). Each run does ONE small job so it always finishes
// inside Netlify's 30-second limit: plan the day, or write one of its seven pitches, or publish it.
import { getStore } from '@netlify/blobs';
import { dayNumberUTC, themeFor, fileFor, scramble, askClaude, parseJSON, planPrompt, pitchPrompt, tidyPitch } from './lib/summit.mjs';

export const config = { schedule: '*/10 8-13 * * *' };

export default async (req, context) => {
  const store = getStore({ name: 'summit', consistency: 'strong' });
  const site = process.env.URL || '';
  const today = dayNumberUTC();

  // Work on the first day (from today up to 2 days ahead) that isn't published yet.
  let target = null;
  for (let n = Math.max(1, today); n <= today + 2; n++) {
    if (await store.get(`day/${n}`)) continue;
    const staticFile = site && await fetch(`${site}/days/${fileFor(n)}`, { method: 'HEAD' }).then(r => r.ok).catch(() => false);
    if (staticFile) continue;
    target = n; break;
  }
  // Testing: set SUMMIT_TEST_DAY (e.g. 12) to build that day straight away.
  const forced = Number(process.env.SUMMIT_TEST_DAY || 0);
  if (forced && !(await store.get(`day/${forced}`))) target = forced;
  if (!target) { console.log('All days ready, nothing to do.'); return; }

  const draftKey = `draft/${target}`;
  const draft = (await store.get(draftKey, { type: 'json' })) || { n: target, theme: themeFor(target), prompts: null, pitches: [], tries: 0 };
  const history = (await store.get('history', { type: 'json' })) || [];

  try {
    if (!draft.prompts) {
      const plan = parseJSON(await askClaude(planPrompt(target, draft.theme, history), 1200));
      const prompts = (plan.prompts || []).filter(p => /^name an? /i.test(p)).slice(0, 7);
      if (prompts.length !== 7) throw new Error('Plan did not return 7 prompts');
      draft.prompts = prompts;
      console.log(`Day ${target} planned:`, prompts.join(' / '));
    } else if (draft.pitches.length < 7) {
      const q = draft.prompts[draft.pitches.length];
      const { pitch, problems, total } = tidyPitch(q, parseJSON(await askClaude(pitchPrompt(draft.theme, q), 6000)));
      if (problems.length) throw new Error(`"${q}" rejected: ${problems.join(', ')}`);
      draft.pitches.push(pitch);
      console.log(`Day ${target} pitch ${draft.pitches.length}/7 done (${total} answers): ${q}`);
    } else {
      const day = { theme: draft.theme, prompts: draft.pitches };
      await store.set(`day/${target}`, JSON.stringify({ v: 1, d: scramble(day) }));
      await store.setJSON('history', history.concat(draft.prompts).slice(-1000));
      await store.delete(draftKey);
      console.log(`Day ${target} published.`);
      return;
    }
    draft.tries = 0;
  } catch (err) {
    draft.tries = (draft.tries || 0) + 1;
    console.log(`Day ${target}: attempt failed (${draft.tries}): ${err.message}`);
    if (draft.tries >= 4 && draft.prompts && draft.pitches.length < 7) {
      // A prompt that keeps failing gets swapped for a fresh one next run.
      history.push(draft.prompts[draft.pitches.length]);
      await store.setJSON('history', history);
      draft.prompts = null; draft.pitches = []; draft.tries = 0;
    }
  }
  await store.setJSON(draftKey, draft);
};
