# The Summit: website project

Everything you need to put The Summit online as a real daily game.

```
the-summit/
├── site/                     ← this whole folder is the website (upload this)
│   ├── index.html            ← page + site settings (launch date etc.)
│   ├── css/styles.css
│   ├── js/loader.js          ← works out today's day and loads its file
│   ├── js/game.js            ← the game itself (Revision 0)
│   ├── days/                 ← one scrambled file per day (Day 1 included)
│   ├── assets/               ← favicon, app icons, link-preview image
│   ├── manifest.webmanifest  ← lets players "Add to Home Screen"
│   └── _headers              ← makes browsers always fetch the latest files
├── content/
│   └── The-Summit-Content.xlsx   ← where you write new days (Day 1 filled in as the example)
└── tools/
    ├── day-builder.html      ← drag the workbook in, download the day files (no install)
    └── build_days.py         ← same thing for the command line (optional)
```

## 1. Try it on your own computer

Browsers won't load the day files straight off your hard drive, so use a tiny local server.

* Easiest: in VS Code, install the **Live Server** extension, open the `site` folder, and click **Go Live**.
* Or, if you have Python: open a terminal in `site/` and run `python3 -m http.server`, then visit `http://localhost:8000`.

## 2. Put it online (free)

**Option A: Netlify drag and drop (no accounts or code tools needed beyond signing up)**
1. Sign up at netlify.com.
2. Go to **Sites → Add new site → Deploy manually**.
3. Drag the **`site`** folder onto the page. You'll get a live address like `the-summit-123.netlify.app` in seconds.
4. To update later, open the site in Netlify, go to **Deploys**, and drag the `site` folder in again.

**Option B: GitHub + Cloudflare Pages (best long term)**
1. Put this project in a GitHub repository.
2. In Cloudflare, go to **Workers & Pages → Create → Pages → Connect to Git** and pick the repo.
3. Leave the build command empty and set the **output directory** to `site`.
4. Every time you push a change to GitHub, the site updates on its own.

**Your own domain:** buy one (Cloudflare, Namecheap, VentraIP…), then add it under the site's **Domains / Custom domains** settings in Netlify or Cloudflare. HTTPS is set up for you.
Once it's live, replace `YOUR-DOMAIN` in the `og:image` and `og:url` lines near the top of `site/index.html` so link previews show the picture.

## 3. Site settings (top of `site/index.html`)

| Setting | What it does |
|---|---|
| `launch` | The date of Day 1 (`YYYY-MM-DD`). Each new local day after that is the next day number. **Set this to your real launch date.** Before it, players see "The first climb opens on…" |
| `key`, `salt` | Used to scramble the day files. Must match the Settings sheet in the workbook. Change them once before launch if you like, then never again. |
| `previewKey` | Test any day early: `yoursite.com/?day=5&key=basecamp` |
| `version` | Add 1 whenever you upload a changed `game.js`, so phones don't keep an old copy. |

## 4. Writing new days

1. Open `content/The-Summit-Content.xlsx` and follow the **Read me** sheet:
   * **Days**: day number + theme (dates fill in from the launch date).
   * **Prompts**: seven rows per day, with the prompt, a climbing pun for the false summits, and an emoji clue for the First ascent.
   * **Answers**: one row per answer, with its grade from the dropdown, any other spellings, and an optional bonus sticker.
   * **Checks**: every pitch should say **OK** (1 First ascent, 3 False summits, 50+ answers).
2. Open `tools/day-builder.html` in your browser and drop the workbook on it.
3. Click **Download all finished days (.zip)**, unzip, and copy the files into `site/days/`.
4. Upload the `site` folder again (or push to GitHub).

If a day's file is missing, players see "Today's climb is still being prepared", so the site never breaks. Aim to have **30 to 60 days ready before launch**.

## 5. Things to know

* **Scrambling is a deterrent, not a lock.** The answers can't be read by just opening the files, and future days have unguessable file names, but a determined coder could still decode them. If cheating becomes a real problem, the next step is a small server function that checks answers so the lists never reach the browser.
* **Progress, best height and stickers are saved on each player's device** (no accounts yet). Clearing browser data resets them, and they don't carry between phone and laptop.
* **Reascend!! lets players replay the same day.** That's great for testing; before launch, decide whether you want to keep it, limit it, or only show a "practice" replay that doesn't count.
* Fonts load from Google Fonts. Everything else is self-contained.
