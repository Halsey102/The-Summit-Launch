/* The Summit: daily loader.
   Works out today's day number from the launch date, fetches that day's
   scrambled content file, decodes it, then starts the game. */
(function () {
  const C = window.SUMMIT_CONFIG;

  // Same scramble the day builder uses (keep in sync with tools/).
  function fnv(s) {
    let h = 0x811c9dc5;
    for (const b of new TextEncoder().encode(s)) { h ^= b; h = Math.imul(h, 0x01000193) >>> 0; }
    return h.toString(16).padStart(8, '0');
  }
  const fileFor = n => `days/${fnv(n + ':' + C.salt)}${fnv(C.salt + ':' + n)}.json`;
  function decode(d) {
    const bin = atob(d), key = new TextEncoder().encode(C.key), out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i) ^ key[i % key.length];
    return JSON.parse(new TextDecoder().decode(out));
  }

  // Day number in the player's own local date (everyone's new puzzle arrives at their midnight).
  function todayNumber() {
    const now = new Date(), [y, m, d] = C.launch.split('-').map(Number);
    const a = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()), b = Date.UTC(y, m - 1, d);
    return Math.floor((a - b) / 86400000) + 1;
  }
  const params = new URLSearchParams(location.search);
  const preview = params.get('key') === C.previewKey && Number(params.get('day')) > 0;
  const day = preview ? Number(params.get('day')) : todayNumber();

  function closed(message) {
    const sp = document.getElementById('splash');
    sp.hidden = false; document.body.classList.add('splash');
    sp.querySelector('.tagline').textContent = message;
    const b = document.getElementById('startbtn'); b.textContent = 'Check back soon'; b.disabled = true;
  }

  if (day < 1) {
    const [y, m, d] = C.launch.split('-').map(Number);
    closed(`The first climb opens on ${new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'long' })}.`);
    return;
  }
  // Hand-made days live in site/days/; automatically generated days come from /api/day.
  const api = `/api/day?n=${day}${preview ? '&key=' + encodeURIComponent(params.get('key')) : ''}`;
  fetch(fileFor(day), { cache: 'no-store' })
    .then(r => r.ok ? r : fetch(api, { cache: 'no-store' }))
    .then(r => { if (!r.ok) throw new Error('missing'); return r.json(); })
    .then(f => {
      const DAY = decode(f.d); DAY.num = day;
      window.DAY = DAY;
      const s = document.createElement('script'); s.src = 'js/game.js?v=' + C.version; document.body.appendChild(s);
    })
    .catch(() => closed('Today\u2019s climb is still being prepared. Check back soon!'));

  // Midnight rollover: when the player's date ticks over, bring in the new day.
  // On the title or results screen it reloads straight away; mid-climb it offers a button instead.
  if (!preview) setInterval(() => {
    const now = todayNumber(); if (now === day) return;
    const b = document.body;
    if (b.classList.contains('splash') || b.classList.contains('finished') || !window.DAY) { location.reload(); return; }
    if (document.getElementById('newday')) return;
    const t = document.createElement('button'); t.id = 'newday';
    t.textContent = `\ud83c\udf05 A new climb is ready! Tap to start Day ${now}`;
    t.onclick = () => location.reload(); b.appendChild(t);
  }, 30000);
})();
