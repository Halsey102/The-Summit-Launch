/* The Summit: game engine.
   Day content (window.DAY) is loaded and decoded by loader.js before this file runs. */
"use strict";
/* ---------- Rules ---------- */
const TIER_INFO = {
  common:   { label: 'Tourist trail', lift: 3,  o2: -15, line: 'Everyone and their nan has walked this path.' },
  uncommon: { label: 'Scramble',      lift: 7,  o2: 0,   line: 'Hands and feet, steady going.' },
  rare:     { label: 'Clean ascent',  lift: 12, o2: 0,   line: 'Smooth moves up the rock.' },
  veryrare: { label: 'Overhang',      lift: 18, o2: 0,   line: 'Hardly anyone dares this line.' },
  ultra:    { label: 'Free solo',     lift: 25, o2: 0,   line: 'No rope, no fear, no company.' },
  gem:      { label: 'First ascent',  lift: 30, o2: 0,   line: 'Nobody has ever climbed this line. Legendary.' },
  stall:    { label: 'Stalled',       lift: 0,  o2: -15, line: 'Frozen on the wall. The clock ran out.' },
  false:    { label: 'False summit',  lift: -5, o2: -10, line: 'Looked like the top. Everyone else thought so too, so you climb back down.' }
};
const POWER = { common: 0, uncommon: 1, rare: 2, veryrare: 3, ultra: 4, gem: 5, false: 0 };
const EVEREST_LIFT = 42, FLOAT_LIFT = 50, SPACE_LIFT = 72, THIN_AIR_COST = 8, VACUUM_COST = 10, WRONG_COST = 15;
const CLOUD_BASE = 16, CLOUD_TOP = 24, TIME_LIMIT = 30;
const MAX_LIFT = 210;
const ZONES = [
  { min: 0,   label: 'Lower slopes' },
  { min: 9,   label: 'Above Kosciuszko',  banner: 'Higher than Kosciuszko!' },
  { min: 18,  label: 'Above Mont Blanc',  banner: 'Higher than Mont Blanc!' },
  { min: 26,  label: 'Above Kilimanjaro', banner: 'Higher than Kilimanjaro!' },
  { min: 33,  label: 'Above Aconcagua',   banner: 'Higher than Aconcagua!' },
  { min: 38,  label: 'Above K2',          banner: 'Higher than K2!' },
  { min: 42,  label: 'Summit of Everest', banner: 'Summit! Hold on tight!' },
  { min: 50,  label: 'Sucked into the sky', banner: 'Whoosh! Ripped off the summit!' },
  { min: 60,  label: 'Stratosphere',      banner: 'Into the stratosphere!' },
  { min: 72,  label: 'Edge of space',     banner: 'You made it to space!' },
  { min: 86,  label: 'Low Earth orbit',   banner: 'Orbiting Earth!' },
  { min: 105, label: 'The Moon',          banner: 'An astronaut waves hello!' },
  { min: 130, label: 'The Milky Way',     banner: 'The whole galaxy in view!' },
  { min: 160, label: 'Alien territory',   banner: 'Aliens spotted!' }
];
const ANCH = [[0,0],[8,2228],[17,4808],[25,5895],[32,6961],[37,8611],[41,8760],[42,8849],[49,9800],[50,10000],[59,12000],[60,15000],[71,50000],[72,100000],[85,350000],[86,408000],[104,300e6],[105,384.4e6],[129,1.5e13],[130,2.46e20],[159,9e20],[160,2.4e22],[210,1.3e26]];
const PIECES = [
  { id: 'pSky', c: 55, span: 7, k: 8 }, { id: 'pStrato', c: 65, span: 7, k: 8 }, { id: 'pEdge', c: 79, span: 8, k: 7 },
  { id: 'pOrbit', c: 95, span: 10, k: 7 }, { id: 'pMoon', c: 117, span: 13, k: 7 }, { id: 'pGalaxy', c: 144, span: 15, k: 6 },
  { id: 'pAliens', c: 178, span: 18, k: 5, stay: true }
];

/* ---------- Matching ---------- */
function norm(s) {
  s = String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  s = s.replace(/&/g, ' and ').replace(/['\u2019`]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
  return s.replace(/^(a|an|the|some)\s+/, '');
}
const compact = s => norm(s).replace(/ /g, '');
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
function lev(a, b) {
  const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
  return prev[n];
}
function buildIndex(p) {
  const out = [];
  for (const tier in p.t) p.t[tier].split(';').map(s => s.trim()).filter(Boolean).forEach(entry => {
    const names = entry.split('|').map(s => s.trim()).filter(Boolean);
    names.forEach(n => out.push({ key: compact(n), display: cap(names[0]), tier }));
  });
  return out;
}
const INDEX = DAY.prompts.map(buildIndex);
function lookup(entries, input) {
  const k = compact(input); if (!k) return null;
  const vars = new Set([k, k + 's']);
  if (k.endsWith('ies')) vars.add(k.slice(0, -3) + 'y');
  if (k.endsWith('es')) vars.add(k.slice(0, -2));
  if (k.endsWith('s')) vars.add(k.slice(0, -1));
  for (const v of vars) { const e = entries.find(x => x.key === v); if (e) return { match: e }; }
  let best = null, bd = Infinity;
  for (const e of entries) { if (Math.abs(e.key.length - k.length) > 3) continue; const d = lev(k, e.key); if (d < bd) { bd = d; best = e; } }
  if (best) { const L = best.key.length, tol = L <= 4 ? 0 : L <= 7 ? 1 : 2;
    if (bd <= tol) return { match: best };
    if (bd <= tol + 1 && k.length >= 5) return { suggest: best }; }
  return { none: true };
}

/* ---------- Altitude ---------- */
function altitude(L) {
  L = Math.max(0, Math.min(MAX_LIFT, L));
  for (let i = 0; i < ANCH.length - 1; i++) { const [l0, a0] = ANCH[i], [l1, a1] = ANCH[i + 1];
    if (L <= l1) { const t = (L - l0) / (l1 - l0); return a0 >= 10000 ? Math.exp(Math.log(a0) + t * (Math.log(a1) - Math.log(a0))) : a0 + t * (a1 - a0); } }
  return ANCH[ANCH.length - 1][1];
}
function fmtAlt(m) {
  if (m < 10000) return Math.round(m).toLocaleString('en-AU') + ' m';
  if (m < 1e9) return Math.round(m / 1000).toLocaleString('en-AU') + ' km';
  if (m < 1e12) return (m / 1e9).toFixed(1) + ' million km';
  if (m < 1e17) return (m / 1e12).toFixed(1) + ' billion km';
  const ly = m / 9.461e15;
  if (ly < 1e6) return Math.round(ly).toLocaleString('en-AU') + ' light-years';
  if (ly < 1e9) return (ly / 1e6).toFixed(1) + ' million light-years';
  return (ly / 1e9).toFixed(1) + ' billion light-years';
}
function zoneIndex(L) { let i = 0; ZONES.forEach((z, j) => { if (L >= z.min) i = j; }); return i; }
function zoneName(L) { return L <= 0 ? 'Base camp' : ZONES[zoneIndex(L)].label; }
const hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const rgb = c => `rgb(${c[0]},${c[1]},${c[2]})`;
const clamp01 = v => Math.max(0, Math.min(1, v));
const STOPS = [[0,'#1C2340'],[CLOUD_BASE,'#3A4566'],[CLOUD_TOP,'#3FB0FF'],[42,'#1E8BFF'],[56,'#2F49E0'],[72,'#1B0F72'],[95,'#0E0640'],[150,'#08032A'],[210,'#030012']];
function skyAt(L) {
  for (let i = 0; i < STOPS.length - 1; i++) { const [l0, c0] = STOPS[i], [l1, c1] = STOPS[i + 1];
    if (L <= l1) return mix(hex(c0), hex(c1), (L - l0) / (l1 - l0)); }
  return hex(STOPS[STOPS.length - 1][1]);
}

/* ---------- World geometry ---------- */
const U = 55, SUMMIT_Y = -EVEREST_LIFT * U;
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const RIDGE = (() => {
  const pts = []; const n = Math.ceil((60 - SUMMIT_Y) / 110);
  for (let i = 0; i <= n; i++) {
    const y = Math.max(SUMMIT_Y + 30, 60 - i * 110);
    const fade = clamp01((y - SUMMIT_Y) / 400);
    pts.push([200 + fade * (22 * Math.sin(i * 1.7) + 12 * Math.sin(i * .6)), y]);
    if (y === SUMMIT_Y + 30) break;
  }
  pts.push([226, SUMMIT_Y - 6]);
  return pts;
})();
const APEX = RIDGE[RIDGE.length - 1];
function ridgeX(y) {
  for (let i = 1; i < RIDGE.length; i++) { const [x0, y0] = RIDGE[i - 1], [x1, y1] = RIDGE[i];
    if (y >= y1) return x0 + (x1 - x0) * (y - y0) / (y1 - y0); }
  return APEX[0];
}
function buildWorld() {
  const P = a => a.map(p => p.map(v => v.toFixed(1)).join(' ')).join(' L');
  let back = '', mtn = '', front = '';
  // distant ridges near the ground
  back += `<path d="M-1400 40 L-900 -260 L-640 -80 L-420 -330 L-180 -60 L60 40 Z" fill="#3A4462"/>`;
  back += `<path d="M-420 -330 L-300 -60 L-180 -60 Z M-900 -260 L-820 -90 L-640 -80 Z" fill="#2E3752"/>`;
  // ground
  back += `<path d="M-3000 0 L${RIDGE[0][0] + 10} 0 L${RIDGE[0][0] + 10} 3000 L-3000 3000 Z" fill="#1D3328"/>`;
  back += `<path d="M-3000 0 L${RIDGE[0][0] + 10} 0 L${RIDGE[0][0] + 10} 14 L-3000 14 Z" fill="#25402F"/>`;
  [[-260, 0, 1.2], [-200, 0, .9], [-140, 0, 1.4], [-60, 0, 1], [-10, 0, 1.25], [60, 0, .85], [110, 0, 1.1]].forEach(([x, y, s]) => {
    back += `<g transform="translate(${x},${y}) scale(${s})"><rect x="-3" y="-10" width="6" height="10" fill="#4A3426"/><path d="M0 -70 L20 -10 L-20 -10 Z" fill="#1F7A4D"/><path d="M0 -70 L20 -10 L0 -10 Z" fill="#14603A"/></g>`;
  });
  back += `<g transform="translate(150,0)"><path d="M-26 0 L0 -30 L26 0 Z" fill="#FF5A1F"/><path d="M0 -30 L26 0 L8 0 Z" fill="#D9400E"/><path d="M0 -30 L-6 0 L6 0 Z" fill="#7A1E06"/></g>`;
  // main mountain
  const right = [[APEX[0] + 50, SUMMIT_Y + 70], [APEX[0] + 130, SUMMIT_Y + 250], [APEX[0] + 250, SUMMIT_Y + 420], [900, SUMMIT_Y + 1100], [1700, 0], [1700, 3000], [RIDGE[0][0], 3000]];
  mtn += `<path d="M${P(RIDGE)} L${P(right)} Z" fill="#8E99AE"/>`;
  // right-hand shaded face
  mtn += `<path d="M${APEX[0]} ${APEX[1]} L${P(right.slice(0, 5))} L1700 3000 L640 3000 L420 ${SUMMIT_Y + 1200} L300 ${SUMMIT_Y + 500} Z" fill="#6B7690"/>`;
  // face streaks
  seed = 11;
  for (let i = 0; i < 70; i++) {
    const y = 40 - rnd() * (40 - SUMMIT_Y - 120), x = ridgeX(y) + 18 + rnd() * 260, len = 80 + rnd() * 160, w = 8 + rnd() * 14;
    const snow = y < SUMMIT_Y + 13 * U;
    mtn += `<path d="M${x} ${y} L${x + w} ${y + 14} L${x + w * .4} ${y + len} L${x - w * .5} ${y + len * .45} Z" fill="${snow ? '#F4F6F9' : (rnd() < .5 ? '#646F88' : '#B3BED0')}"/>`;
  }
  // light facets along the ridge
  for (let i = 0; i < RIDGE.length - 2; i += 2) {
    const [x, y] = RIDGE[i];
    mtn += `<path d="M${x + 4} ${y} L${x + 46} ${y - 30} L${x + 14} ${y - 96} Z" fill="${y < SUMMIT_Y + 13 * U ? '#FFFFFF' : '#BAC4D6'}" opacity=".9"/>`;
  }
  // summit snow cap
  const sy = SUMMIT_Y;
  mtn += `<path d="M${APEX[0]} ${APEX[1]} L${APEX[0] + 50} ${sy + 70} L${APEX[0] + 92} ${sy + 132} L${APEX[0] + 70} ${sy + 118} L${APEX[0] + 58} ${sy + 160} L${APEX[0] + 34} ${sy + 126} L${APEX[0] + 18} ${sy + 176} L${APEX[0]} ${sy + 140} L${ridgeX(sy + 190) + 2} ${sy + 190} L${ridgeX(sy + 120)} ${sy + 120} Z" fill="#F7F9FB"/>`;
  mtn += `<path d="M${APEX[0]} ${APEX[1]} L${APEX[0] + 50} ${sy + 70} L${APEX[0] + 92} ${sy + 132} L${APEX[0] + 70} ${sy + 118} L${APEX[0] + 58} ${sy + 160} L${APEX[0] + 34} ${sy + 126} Z" fill="#DCE3EB"/>`;
  // fixed rope along the ridge
  const rope = RIDGE.filter(p => p[1] < 40).map(([x, y]) => [x - 5, y]);
  mtn += `<polyline points="${rope.map(p => p.join(',')).join(' ')}" fill="none" stroke="#FFC21A" stroke-width="2.2"/>`;
  rope.forEach(([x, y], i) => { if (i % 2 === 0) mtn += `<rect x="${x - 2.5}" y="${y - 2.5}" width="5" height="5" fill="#4A566B"/>`; });
  // summit flag + gusts
  mtn += `<rect x="${APEX[0] - 1.5}" y="${APEX[1] - 64}" width="3" height="64" fill="#3A4152"/>`;
  mtn += `<path class="sumflag" d="M${APEX[0] + 1} ${APEX[1] - 64} L${APEX[0] + 40} ${APEX[1] - 54} L${APEX[0] + 1} ${APEX[1] - 42} Z" fill="#FF2D45"/>`;
  mtn += `<g class="gust">${[-40, -14, 30, 54].map((dx, i) => `<line x1="${APEX[0] + dx}" y1="${APEX[1] - 40 - i * 8}" x2="${APEX[0] + dx}" y2="${APEX[1] - 80 - i * 8}"/>`).join('')}</g>`;
  // cloud deck
  seed = 23;
  const deck = (yc, col, n, rmin, rmax, k) => { let s = ''; for (let i = 0; i < n; i++) { const x = -1500 + i * (3400 / n) + rnd() * 60, r = rmin + rnd() * (rmax - rmin); s += `<ellipse class="cloudpuff ${k}" cx="${x.toFixed(0)}" cy="${(yc + rnd() * 50 - 25).toFixed(0)}" rx="${(r * 1.5).toFixed(0)}" ry="${r.toFixed(0)}" fill="${col}"/>`; } return s; };
  front += deck(-CLOUD_BASE * U + 30, '#8F9AB0', 26, 70, 110, 'k2');
  front += deck(-(CLOUD_BASE + 3) * U, '#C3CCDA', 26, 80, 130, '');
  front += deck(-(CLOUD_BASE + 6) * U, '#E7EBF1', 24, 80, 120, 'k3');
  front += deck(-CLOUD_TOP * U + 30, '#F7F9FB', 20, 60, 100, 'k2');
  // the forest valley below base camp (seen from the title screen)
  seed = 41;
  const ridgeLine = (base, a1, a2) => x => base + a1 * Math.sin(x / 90) + a2 * Math.sin(x / 37 + 1.3);
  const layer = (base, fill, treeFill, a1, a2, tmin, tmax) => {
    const f = ridgeLine(base, a1, a2); let d = `M-1600 ${f(-1600).toFixed(0)}`;
    for (let x = -1560; x <= 2000; x += 40) d += ` L${x} ${f(x).toFixed(0)}`;
    d += ' L2000 1400 L-1600 1400 Z';
    let t = '';
    for (let x = -1580; x <= 1980; x += 22 + rnd() * 10) { const y = f(x) + 4, s = tmin + rnd() * (tmax - tmin);
      t += `M${x.toFixed(0)} ${(y - s).toFixed(0)} L${(x + s * .32).toFixed(0)} ${y.toFixed(0)} L${(x - s * .32).toFixed(0)} ${y.toFixed(0)} Z `; }
    return `<path d="${d}" fill="${fill}"/><path d="${t}" fill="${treeFill}"/>`;
  };
  let valley = layer(120, '#18301F', '#1E4A30', 16, 9, 26, 46);
  valley += `<ellipse cx="200" cy="215" rx="900" ry="26" fill="rgba(190,205,225,.13)"/>`;
  valley += layer(270, '#132819', '#183D27', 22, 10, 22, 38);
  valley += `<path d="M-1600 452 Q-1200 430 -800 452 T0 448 T800 452 T1600 446 L2000 446 L2000 498 L-1600 498 Z" fill="#2C527A"/>`;
  valley += `<path d="M-1400 466 q60 -8 120 0 M-700 474 q50 -6 100 0 M-100 468 q70 -9 140 0 M500 474 q60 -8 120 0 M1100 466 q50 -7 100 0" stroke="#5C8FC4" stroke-width="3" fill="none"/>`;
  valley += layer(520, '#0E1F15', '#123020', 14, 8, 20, 34);
  valley += `<ellipse cx="300" cy="400" rx="1100" ry="30" fill="rgba(190,205,225,.12)"/>`;
  front += valley;
  // birds: flocks above the clouds and choughs circling the summit
  const bird = (s, col, slow) => `<g transform="scale(${s})"><path class="wingf${slow ? ' slow' : ''}" d="M-1 -1 Q-6 -15 -15 -18 Q-6 -6 3 -1 Z" fill="${col}" opacity=".7"/><path d="M-12 0 L-19 -4 L-18 0 L-19 4 Z" fill="${col}"/><ellipse cx="0" cy="0" rx="9" ry="3.6" fill="${col}"/><circle cx="8" cy="-1.5" r="3.2" fill="${col}"/><path d="M10.5 -2.5 L15.5 -1 L10.5 .5 Z" fill="#FFC21A"/><path class="wingf${slow ? ' slow' : ''}" d="M-3 -1 Q-2 -16 -10 -22 Q2 -10 5 -1 Z" fill="${col}"/></g>`;
  for (let f = 0; f < 3; f++) {
    const y = -(CLOUD_TOP + 4 + f * 4) * U;
    front += `<g class="bird${f % 2 ? ' b2' : ''}"><g transform="translate(0,${y})">${[0, 1, 2].map(j => `<g transform="translate(${j * 26},${(j % 2) * 12})">${bird(.9, '#1A1F2E')}</g>`).join('')}</g></g>`;
  }
  const cx = APEX[0], cy = APEX[1] - 70;
  [[70, 8, '', .85, '#151A28'], [115, 12, ' ccw', 1, '#151A28'], [165, 17, '', 1.15, '#151A28'], [230, 24, ' ccw', 1.9, '#5A3A22']].forEach(([r, d, dir, sc, col], i) => {
    front += `<g class="circler${dir}" style="animation-duration:${d}s;animation-delay:-${i * 3}s;transform-origin:${cx}px ${cy}px"><g transform="translate(${cx + r},${cy}) rotate(${dir ? -90 : 90})">${bird(sc, col, i === 3)}</g></g>`;
  });
  $('worldBack').innerHTML = back; $('worldMtn').innerHTML = mtn; $('worldFront').innerHTML = front;
}

/* ---------- State ---------- */
const KEY = 'summit-v6-day-' + DAY.num;
const fresh = () => ({ started: false, idx: 0, lift: 0, o2: 100, phase: 'ask', results: [], done: false, outOfAir: false, lastResult: null, quick: 0, gems: 0, falses: 0, wrong: 0 });
let S = fresh();
try { const raw = localStorage.getItem(KEY); if (raw) S = Object.assign(fresh(), JSON.parse(raw)); } catch (e) {}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
const $ = id => document.getElementById(id);
const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const sleep = ms => new Promise(r => setTimeout(r, reduceMotion ? Math.min(ms, 80) : ms));

/* ---------- Sound: everything is synthesised live with Web Audio (no audio files) ---------- */
const Sound = (() => {
  let ctx = null, master, amb, sfx, noiseBuf, rainBuf, cur = null, curName = null, wanted = null, muted = false;
  try { muted = localStorage.getItem('summit-muted') === '1'; } catch (e) {}
  const now = () => ctx.currentTime;
  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = muted ? 0 : .7; master.connect(ctx.destination);
    amb = ctx.createGain(); amb.gain.value = .45; amb.connect(master);
    sfx = ctx.createGain(); sfx.gain.value = 1.35; sfx.connect(master);
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -10; comp.ratio.value = 4; master.disconnect(); master.connect(comp); comp.connect(ctx.destination);
    const len = ctx.sampleRate * 2; noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // Rain on forest leaves: thousands of soft, dull 'pats' (filtered noise ticks) at uneven loudness.
    const rl = ctx.sampleRate * 4; rainBuf = ctx.createBuffer(2, rl, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d2 = rainBuf.getChannelData(ch);
      for (let k = 0; k < 2600; k++) {
        const start = Math.floor(Math.random() * rl), amp = Math.pow(Math.random(), 3) * .5 + .02, dec = 40 + Math.random() * 260, a = .55 + Math.random() * .4;
        let y = 0;
        for (let i = 0; i < 1600 && start + i < rl; i++) { y = a * y + (1 - a) * (Math.random() * 2 - 1); d2[start + i] += amp * 3 * y * Math.exp(-i / dec); }
      } }
    if (wanted) { const w = wanted; wanted = null; scene(w); }
  }
  const G = v => { const g = ctx.createGain(); g.gain.value = v; return g; };
  const F = (type, f, q) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q) b.Q.value = q; return b; };
  const O = (type, f) => { const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; return o; };
  const RAIN = (vol, s) => { const r = ctx.createBufferSource(); r.buffer = rainBuf; r.loop = true; const lp = F('lowpass', 2600), hp = F('highpass', 180), g = G(vol); r.connect(hp); hp.connect(lp); lp.connect(g); g.connect(s.out); r.start(0, Math.random() * 3); s.nodes.push(r);
    const rs = N(), rl2 = F('lowpass', 900), rg = G(vol * .12); rs.connect(rl2); rl2.connect(rg); rg.connect(s.out); rs.start(); s.nodes.push(rs); lfo(.3, vol * .05, rg.gain, s.nodes); };
  const N = () => { const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true; return s; };
  function lfo(rate, depth, param, list) { const o = O('sine', rate), g = G(depth); o.connect(g); g.connect(param); o.start(); list.push(o); }
  function tone(f, dur, type, vol, when, slideTo, dest) {
    if (!ctx) return; const t = now() + (when || 0), o = O(type || 'sine', f), g = G(0); o.connect(g); g.connect(dest || sfx);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol || .2, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    o.start(t); o.stop(t + dur + .05);
  }
  function burst(dur, type, f, vol, when, dest) {
    if (!ctx) return; const t = now() + (when || 0), s = ctx.createBufferSource(); s.buffer = noiseBuf; const fl = F(type, f), g = G(0);
    s.connect(fl); fl.connect(g); g.connect(dest || sfx);
    g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(vol, t + .015); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    s.start(t, Math.random()); s.stop(t + dur + .05);
  }
  function chirp(dest) {
    const base = 2600 + Math.random() * 2200, n = 2 + Math.floor(Math.random() * 3), gap = .08 + Math.random() * .06;
    for (let i = 0; i < n; i++) tone(base + Math.random() * 600, .07 + Math.random() * .05, 'sine', .05, i * gap, base * (Math.random() < .5 ? .7 : 1.3), dest);
  }
  // Each ambient scene builds a little sound graph that fades in and out as the climber moves.
  const SCENES = {
    storm(s) {
      RAIN(.1, s);
      const b = N(), bl = F('lowpass', 120), bg = G(.16); b.connect(bl); bl.connect(bg); bg.connect(s.out); b.start(); s.nodes.push(b);
      lfo(.11, .06, bg.gain, s.nodes);
    },
    cloud(s) {
      RAIN(.04, s);
      const w = N(), wl = F('lowpass', 500), wg = G(.06); w.connect(wl); wl.connect(wg); wg.connect(s.out); w.start(); s.nodes.push(w);
      lfo(.2, 200, wl.frequency, s.nodes);
    },
    clear(s) {
      const w = N(), wl = F('lowpass', 380), wg = G(.03); w.connect(wl); wl.connect(wg); wg.connect(s.out); w.start(); s.nodes.push(w);
      const loop = () => { chirp(s.out); s.timers.push(setTimeout(loop, 400 + Math.random() * 1800)); }; loop();
    },
    sky(s) {
      const w = N(), bp = F('bandpass', 650, .7), wg = G(.12); w.connect(bp); bp.connect(wg); wg.connect(s.out); w.start(); s.nodes.push(w);
      lfo(.23, 420, bp.frequency, s.nodes); lfo(.17, .04, wg.gain, s.nodes);
    },
    fall(s) {
      const w = N(), bp = F('bandpass', 900, .9), wg = G(.2); w.connect(bp); bp.connect(wg); wg.connect(s.out); w.start(); s.nodes.push(w);
      lfo(1.4, 500, bp.frequency, s.nodes);
    },
    edge(s) {
      const lp = F('lowpass', 320), g = G(.03); lp.connect(g); g.connect(s.out);
      [55, 55.6, 82.4].forEach(f => { const o = O('sawtooth', f); o.connect(lp); o.start(); s.nodes.push(o); });
      const h = N(), hl = F('lowpass', 450), hg = G(.015); h.connect(hl); hl.connect(hg); hg.connect(s.out); h.start(); s.nodes.push(h);
      lfo(.07, 140, lp.frequency, s.nodes);
    },
    orbit(s) {
      SCENES.edge(s);
      const loop = () => { tone(1250, .07, 'sine', .025, 0, null, s.out); tone(1250, .07, 'sine', .025, .14, null, s.out); burst(.25, 'bandpass', 2500, .015, .4, s.out);
        s.timers.push(setTimeout(loop, 2200 + Math.random() * 2600)); }; loop();
    },
    moon(s) {
      const g = G(.022); g.connect(s.out);
      [110, 164.8, 220].forEach(f => { const o = O('sine', f); o.connect(g); o.start(); s.nodes.push(o); });
      lfo(.18, .025, g.gain, s.nodes);
    },
    galaxy(s) {
      const g = G(.015); g.connect(s.out);
      [220, 277.2, 329.6, 440].forEach((f, i) => { const o = O('sine', f); o.connect(g); o.start(); s.nodes.push(o); lfo(.05 + i * .03, 1.5, o.frequency, s.nodes); });
      const loop = () => { tone(1200 + Math.random() * 1400, 1.4, 'sine', .018, 0, null, s.out); s.timers.push(setTimeout(loop, 900 + Math.random() * 1800)); }; loop();
    },
    aliens(s) {
      const o = O('sine', 520), g = G(.02); o.connect(g); g.connect(s.out); o.start(); s.nodes.push(o);
      lfo(6, 9, o.frequency, s.nodes); lfo(.12, 160, o.frequency, s.nodes);
      const loop = () => { if (!ctx) return; const t = now(), u = O('triangle', 300), ug = G(0); u.connect(ug); ug.connect(s.out);
        ug.gain.setValueAtTime(0, t); ug.gain.linearRampToValueAtTime(.025, t + .3); ug.gain.linearRampToValueAtTime(0, t + 1.6);
        const l = O('sine', 11), lg = G(140); l.connect(lg); lg.connect(u.frequency); u.start(t); l.start(t); u.stop(t + 1.7); l.stop(t + 1.7);
        s.timers.push(setTimeout(loop, 3500 + Math.random() * 3500)); }; loop();
    }
  };
  function scene(name) {
    if (!ctx) { wanted = name; return; }
    if (name === curName) return;
    const old = cur; curName = name; cur = null;
    if (old) { const t = now(); old.out.gain.cancelScheduledValues(t); old.out.gain.setValueAtTime(old.out.gain.value, t); old.out.gain.linearRampToValueAtTime(0, t + 2);
      old.timers.forEach(clearTimeout); setTimeout(() => { old.nodes.forEach(n => { try { n.stop(); } catch (e) {} }); old.out.disconnect(); }, 2300); }
    if (!name || !SCENES[name]) return;
    const s = { out: G(0), nodes: [], timers: [] }; s.out.connect(amb); SCENES[name](s);
    const t = now(); s.out.gain.setValueAtTime(0, t); s.out.gain.linearRampToValueAtTime(1, t + 2.2); cur = s;
  }
  function setMuted(m) {
    muted = m; try { localStorage.setItem('summit-muted', m ? '1' : '0'); } catch (e) {}
    if (ctx) { const t = now(); master.gain.cancelScheduledValues(t); master.gain.linearRampToValueAtTime(m ? 0 : .7, t + .15); }
    document.querySelectorAll('.sndbtn').forEach(b => { b.innerHTML = icon(); b.setAttribute('aria-label', m ? 'Sound off' : 'Sound on'); });
  }
  const icon = () => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 9 H7 L12 5 V19 L7 15 H3 Z" fill="currentColor"/>${muted ? '<path d="M16 9 L22 15 M22 9 L16 15" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' : '<path d="M15.5 8.5 Q18 12 15.5 15.5 M18.5 6 Q22.5 12 18.5 18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>'}</svg>`;
  const C = [523.25, 659.25, 783.99, 1046.5, 1318.5, 1568];
  return {
    init, scene, icon, setMuted, get muted() { return muted; },
    click() { tone(1700, .03, 'triangle', .07); },
    tick() { tone(1050, .035, 'square', .035); },
    whoosh() { burst(.45, 'bandpass', 1100, .12); },
    chime() { tone(1046.5, .25, 'sine', .08); tone(1568, .35, 'sine', .07, .09); },
    slap() { burst(.14, 'lowpass', 900, .45); },
    sticker() { burst(.12, 'lowpass', 900, .35); tone(880, .15, 'triangle', .08, .02); tone(1320, .25, 'triangle', .08, .11); },
    wrong() { tone(150, .18, 'square', .09); tone(118, .3, 'square', .09, .17); },
    thunder(big) {
      if (!ctx) return;
      if (big) {
        // Whip crack: a quick rising swish, then a violent snap, a slap-back echo, and a long roll.
        const t = now(), sw = ctx.createBufferSource(); sw.buffer = noiseBuf; const bp = F('bandpass', 400, 2), sg = G(0);
        sw.connect(bp); bp.connect(sg); sg.connect(sfx); bp.frequency.setValueAtTime(400, t); bp.frequency.exponentialRampToValueAtTime(4200, t + .14);
        sg.gain.setValueAtTime(.0001, t); sg.gain.exponentialRampToValueAtTime(.5, t + .13); sg.gain.exponentialRampToValueAtTime(.0001, t + .16); sw.start(t); sw.stop(t + .2);
        burst(.035, 'highpass', 3000, 2.2, .14); burst(.08, 'bandpass', 1600, 1.6, .145); burst(.18, 'lowpass', 2500, 1, .15);
        burst(.06, 'highpass', 2200, .55, .42); burst(.06, 'highpass', 2200, .25, .66);
        burst(4.6, 'lowpass', 110, 1, .3); burst(3.6, 'lowpass', 60, .9, .55);
        return;
      }
      burst(.07, 'highpass', 1400, .7);
      for (let i = 0; i < 4; i++) burst(.05, 'bandpass', 1000 + Math.random() * 2200, .4 - i * .07, .03 + i * .05);
      burst(3, 'lowpass', 100, .55, .12); burst(2.2, 'lowpass', 60, .45, .35);
    },
    tier(t) {
      if (!ctx) return;
      if (t === 'false') { tone(260, .6, 'sawtooth', .07, 0, 110); burst(.3, 'lowpass', 300, .4); return; }
      if (t === 'stall') { tone(700, .7, 'square', .045, 0, 140); return; }
      if (t === 'common') { tone(330, .22, 'triangle', .12); return; }
      const n = { uncommon: 2, rare: 3, veryrare: 4, ultra: 5, gem: 6 }[t] || 2, gap = t === 'ultra' || t === 'gem' ? .065 : .09;
      for (let i = 0; i < n; i++) tone(C[i], .3, 'triangle', .11, i * gap);
      if (t === 'gem') for (let i = 0; i < 8; i++) tone(2000 + Math.random() * 2200, .25, 'sine', .04, .4 + i * .05);
    },
    strike() {
      if (!ctx) return;
      // A cinematic 'hit': deep falling boom, a bright shimmer, and a rising whoosh into the climb.
      tone(150, 1.6, 'sine', .9, 0, 34); tone(75, 1.8, 'triangle', .45, 0, 30);
      burst(.5, 'lowpass', 500, .7, 0);
      [523.25, 783.99, 1046.5, 1568].forEach((f, i) => tone(f, 1.8, 'sine', .07, .05 + i * .02));
      const t = now() + .9, s = ctx.createBufferSource(); s.buffer = noiseBuf; const bp = F('bandpass', 300, 1.2), g = G(.0001);
      s.connect(bp); bp.connect(g); g.connect(sfx); bp.frequency.setValueAtTime(300, t); bp.frequency.exponentialRampToValueAtTime(3000, t + 1);
      g.gain.exponentialRampToValueAtTime(.25, t + .9); g.gain.exponentialRampToValueAtTime(.0001, t + 1.2); s.start(t); s.stop(t + 1.3);
    },
    fanfare() { if (!ctx) return; [0, 2, 4].forEach((k, i) => tone([523.25, 659.25, 783.99][i], .18, 'triangle', .12, i * .13)); [523.25, 659.25, 783.99, 1046.5].forEach(f => tone(f, 1.1, 'triangle', .07, .42)); }
  };
})();
['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, () => Sound.init(), true));
document.addEventListener('click', e => { if (e.target.closest && e.target.closest('button') && !e.target.closest('.sndbtn')) Sound.click(); }, true);
function sceneFor(L) {
  if (modeFor(L) === 'fall') return 'fall';
  if (L >= 160) return 'aliens'; if (L >= 130) return 'galaxy'; if (L >= 105) return 'moon';
  if (L >= 86) return 'orbit'; if (L >= SPACE_LIFT) return 'edge'; if (L >= FLOAT_LIFT) return 'sky';
  if (L >= CLOUD_TOP) return 'clear'; if (L >= CLOUD_BASE) return 'cloud'; return 'storm';
}
let shownLift = S.lift, busy = false;
const BEST_KEY = 'summit-best';
let best = 0; try { best = +localStorage.getItem(BEST_KEY) || 0; } catch (e) {}
function finishRun() {
  if (S.outOfAir) award('freefall');
  else { award('firstclimb'); if (!S.wrong) award('cleansweep'); if (S.o2 <= 10) award('lastgasp'); if (S.o2 >= 100) award('fulltank'); }
  if (S.lift > best) { best = S.lift; try { localStorage.setItem(BEST_KEY, String(best)); } catch (e) {} }
}
function paintBest() {
  const show = best > 0 && !S.done;
  const label = `Your best: ${fmtAlt(altitude(best))}`;
  const flag = (x, y, lw) => `<g transform="translate(${x},${y})"><rect x="-1.5" y="-80" width="3" height="80" fill="#3A4152"/><path class="sumflag" d="M1.5 -80 L44 -70 L1.5 -58 Z" fill="#FFC21A"/><path d="M14 -73 l2 4 l4 .5 l-3 2.6 l1 4 l-4 -2 l-4 2 l1 -4 l-3 -2.6 l4 -.5 Z" fill="#141A2E"/>
    <rect x="-${lw / 2}" y="6" width="${lw}" height="20" rx="2" fill="#141A2E"/><text class="bestlabel" x="0" y="20" text-anchor="middle" font-size="11" fill="#FFC21A">${label}</text></g>`;
  const lw = label.length * 6.6 + 14;
  if (show && best < FLOAT_LIFT) {
    const y = best >= EVEREST_LIFT ? APEX[1] + 50 : -best * U, x = best >= EVEREST_LIFT ? APEX[0] + 30 : ridgeX(y) + 22;
    $('bestflag').innerHTML = flag(x, y, lw); $('pBest').innerHTML = '';
  } else if (show) {
    $('bestflag').innerHTML = '';
    $('pBest').innerHTML = `<g transform="translate(320,190)"><path d="M-46 14 L-30 -12 L6 -20 L40 -8 L48 16 L22 32 L-28 30 Z" fill="#7C8799"/><path d="M-30 -12 L6 -20 L40 -8 L10 -2 Z" fill="#9AA6B8"/><circle cx="-10" cy="10" r="6" fill="#5E6A80"/><circle cx="22" cy="16" r="4" fill="#5E6A80"/></g>${flag(318, 176, lw)}`;
  } else { $('bestflag').innerHTML = ''; $('pBest').innerHTML = ''; }
}

/* ---------- World paint ---------- */
function modeFor(L) {
  if (S.outOfAir && L >= S.lift - .01) return 'fall';
  if (S.done && L >= S.lift - .01) return 'celebrate';
  if (L >= SPACE_LIFT) return 'space';
  if (L >= FLOAT_LIFT) return 'sky';
  if (L >= EVEREST_LIFT) return 'summit';
  return 'climb';
}
function weatherFor(L) {
  if (L >= SPACE_LIFT) return 'space';
  if (L < CLOUD_BASE) return 'storm';
  if (L < CLOUD_TOP) return 'cloud';
  return S.o2 <= 25 ? 'spindrift' : 'clear';
}
function fitAlt(L) {
  const el = $('alt'), hype = clamp01(L / 150);
  const st = document.documentElement.style;
  st.setProperty('--hype', hype.toFixed(3));
  st.setProperty('--glow', L >= SPACE_LIFT ? '90,200,255' : '242,185,46');
  const w = el.parentElement.clientWidth || 320;
  const want = Math.min(40, Math.max(30, window.innerWidth * .08)) * (1 + hype * .9);
  el.style.fontSize = Math.min(want, w / (el.textContent.length * .66)).toFixed(1) + 'px';
}

const CHECKS = [[0, 'Base camp'], [CLOUD_TOP, 'Above the clouds'], [EVEREST_LIFT, 'Everest'], [FLOAT_LIFT, 'Lift-off'], [SPACE_LIFT, 'Space'], [86, 'Orbit'], [105, 'The Moon'], [130, 'Milky Way'], [160, '']];
const PTOP = 86;
(function buildProg() {
  const box = $('prog'), me = $('pme');
  CHECKS.forEach(([l, name], i) => { const d = document.createElement('div');
    d.className = 'pdot' + (i === CHECKS.length - 1 ? ' far' : ''); d.style.bottom = (i / (CHECKS.length - 1) * PTOP) + '%';
    d.innerHTML = name ? `<span class="pl">${name}</span>` : ''; box.insertBefore(d, me); });
})();
function paintProg(L) {
  let pos = PTOP;
  for (let i = 0; i < CHECKS.length - 1; i++) if (L < CHECKS[i + 1][0]) { pos = (i + (L - CHECKS[i][0]) / (CHECKS[i + 1][0] - CHECKS[i][0])) / (CHECKS.length - 1) * PTOP; break; }
  pos = Math.max(0, pos);
  $('pme').style.bottom = pos + '%'; $('pfill').style.height = pos + '%';
  document.querySelectorAll('#prog .pdot').forEach((d, i) => d.classList.toggle('got', L >= CHECKS[i][0] && L > 0 || i === 0));
}
let camOff = 0;
const SPLASH_CAM = -560;

/* The opening thunderclap: a huge bolt, a white-out, then cut to the climber close up. */
function boltPath() {
  let x = 46 + Math.random() * 14, y = 0, d = `M${x} 0`;
  while (y < 100) { y += 5 + Math.random() * 7; x += (Math.random() - .5) * 14; d += ` L${x.toFixed(1)} ${Math.min(100, y).toFixed(1)}`; }
  return d;
}
async function bigStrike() {
  const box = $('bigstrike'), stage = $('stage');
  const d = boltPath(), b1 = d.replace(/ L/g, '|').split('|'), cut = Math.floor(b1.length * .45);
  let fork = b1[cut].replace('M', '').split(' ').map(Number); let fx = fork[0], fy = fork[1], fd = `M${fx} ${fy}`;
  for (let i = 0; i < 5; i++) { fy += 5 + Math.random() * 6; fx += 4 + Math.random() * 6; fd += ` L${fx.toFixed(1)} ${fy.toFixed(1)}`; }
  box.innerHTML = `<svg viewBox="0 0 100 100" preserveAspectRatio="none"><path class="glow" d="${d}"/><path class="glow" d="${fd}"/><path class="core" d="${d}"/><path class="core thin" d="${fd}"/></svg><div class="white"></div>`;
  box.classList.remove('go'); void box.offsetWidth; box.classList.add('go'); Sound.strike();
  if (!reduceMotion) pulseClass($('app'), 'thunder', 900);
  await sleep(760);
  camOff = 0; paintClimber();
  stage.classList.add('snap', 'closeup'); void stage.offsetWidth; stage.classList.remove('snap');
  await sleep(1240);
}
function camTo(target, dur) {
  const from = camOff;
  if (reduceMotion) { camOff = target; paintClimber(); return Promise.resolve(); }
  const t0 = performance.now();
  return new Promise(res => { const step = now => { const t = Math.min(1, (now - t0) / dur), e = t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    camOff = from + (target - from) * e; paintClimber(); if (t < 1) requestAnimationFrame(step); else res(); }; requestAnimationFrame(step); });
}
function setCls(el, c, on) { if (el.classList.contains(c) !== !!on) el.classList.toggle(c, !!on); }
function cull(L) {
  const st = $('stage'), mtnOn = L < 66 || st.dataset.mode === 'fall' && S.lift < 66;
  ['worldBack', 'worldMtn', 'worldFront', 'bestflag'].forEach(id => setCls($(id), 'world-off', !mtnOn));
  setCls(st, 'b-trees', L < 20);
  setCls(st, 'b-deck', L > CLOUD_BASE - 10 && L < CLOUD_TOP + 14);
  setCls(st, 'b-flocks', L > CLOUD_TOP - 3 && L < 52);
  setCls(st, 'b-summit', L > 32 && L < 58);
}
function paintWorld(L) {
  Sound.scene(sceneFor(L));
  paintProg(L);
  const wx = weatherFor(L);
  document.body.dataset.wx = wx;
  document.documentElement.style.setProperty('--sky', rgb(skyAt(L)));
  $('gloom').style.opacity = wx === 'storm' ? .32 : wx === 'cloud' ? .12 : 0;
  $('fog').style.opacity = (clamp01(1 - Math.abs(L - (CLOUD_BASE + CLOUD_TOP) / 2) / 4.5) * .8).toFixed(2);
  const so = clamp01((L - 56) / 18), su = clamp01((L - CLOUD_TOP) / 4) * (1 - clamp01((L - 56) / 10)) * (S.o2 <= 25 ? .4 : 1), po = clamp01((L - CLOUD_TOP + 1) / 3) * (1 - clamp01((L - 50) / 8));
  $('stars').style.opacity = so.toFixed(2); setCls($('stars'), 'bg-off', so <= 0);
  $('sun').style.opacity = su.toFixed(2); setCls($('sun'), 'bg-off', su <= 0);
  $('peaks').style.opacity = po.toFixed(2); setCls($('peaks'), 'bg-off', po <= 0);
  cull(L);
  $('peaks').style.transform = `translateY(${Math.max(0, L - 42) * 22}px)`;
  const all = best >= FLOAT_LIFT && !S.done ? PIECES.concat([{ id: 'pBest', c: best, span: 9, k: 7 }]) : PIECES;
  let nextReady = false;
  all.slice().sort((a, b) => a.c - b.c).forEach(p => { const el = $(p.id); let o, y;
    if (p.stay && L >= p.c) { o = 1; y = 0; } else { o = clamp01(1 - Math.abs(L - p.c) / p.span); y = (L - p.c) * p.k; }
    const st = o > 0 ? 'on' : (!nextReady && L < p.c - p.span) ? (nextReady = true, 'ready') : 'off';
    if (el._st !== st) { el._st = st; setCls(el, 'scene-off', st === 'off'); setCls(el, 'scene-ready', st === 'ready'); }
    if (st === 'off') return;
    el.setAttribute('opacity', o.toFixed(2)); el.setAttribute('transform', `translate(0,${y.toFixed(1)})`); });
  if (!(best >= FLOAT_LIFT && !S.done)) setCls($('pBest'), 'scene-off', true);
  $('alt').textContent = fmtAlt(altitude(L));
  $('zone').textContent = zoneName(L);
  fitAlt(L);
  paintClimber(L);
}
let faceOverride = null, faceTimer = null;
function paintClimber(L) {
  if (L === undefined) L = shownLift;
  const sc = $('stage'), o2 = Math.max(0, S.o2), mode = modeFor(L);
  let sev = 0;
  if (mode === 'climb') { if (L >= 18 || o2 <= 75) sev = 1; if (L >= 33 || o2 <= 50) sev = 2; if (o2 <= 25) sev = 3; }
  else if (mode !== 'down') sev = o2 <= 25 ? 3 : o2 <= 50 ? 2 : o2 <= 75 ? 1 : 0;
  let face;
  if (mode === 'fall') face = 'gasp';
  else if (mode === 'celebrate') face = L >= SPACE_LIFT ? 'wow' : 'happy';
  else if (mode === 'summit' || sev === 3) face = 'gasp';
  else if (sev === 2) face = 'tired';
  else if (mode === 'space') face = 'wow';
  else if (mode === 'sky' || sev === 0) face = 'happy';
  else face = 'ok';
  sc.dataset.mode = mode; sc.dataset.sev = sev; sc.dataset.where = L >= FLOAT_LIFT ? 'air' : 'mtn'; sc.dataset.zone = (mode === 'sky' || mode === 'space') ? String([50, 60, 72, 86, 105, 130, 160].filter(z => L >= z).length - 1) : ''; sc.dataset.space = L >= SPACE_LIFT ? 1 : 0; sc.dataset.face = faceOverride || face;
  sc.classList.toggle('low-tank', o2 <= 25 && o2 > 0);
  const h = 30 * o2 / 100, f = $('tankFill');
  f.setAttribute('height', h.toFixed(1)); f.setAttribute('y', (-86 + 30 - h).toFixed(1));
  f.setAttribute('fill', o2 <= 25 ? '#FF2D45' : '#19D98A');
  // climber in world + camera
  let wx, wy, ax = 0, ay = 0, s = 1.15, sx, sy;
  if (mode === 'celebrate') {
    if (L >= FLOAT_LIFT) { wy = APEX[1] - 200 - (L - FLOAT_LIFT) * U * 1.6; wx = 200; ay = -60; s = .95; sx = 200; sy = 352; }
    else if (L >= EVEREST_LIFT) { wx = APEX[0] - 14; wy = APEX[1] + 6; s = 1.1; sx = 185; sy = 430; }
    else { const yy = -L * U; wx = ridgeX(yy - 70) - 20; wy = yy; sx = 175; sy = 432; }
    confetti(true, L >= SPACE_LIFT);
    $('myflag').setAttribute('transform', `translate(${(wx + (L >= EVEREST_LIFT ? -30 : 30)).toFixed(1)},${(wy + 2).toFixed(1)})`);
  } else if (mode === 'fall') {
    const base = L >= FLOAT_LIFT ? APEX[1] - 200 - (L - FLOAT_LIFT) * U * 1.6 : L >= EVEREST_LIFT ? APEX[1] - 60 : -L * U;
    wx = L >= EVEREST_LIFT ? 200 : ridgeX(base - 70) - 40; wy = base + fallY; ay = -60; s = 1.05; sx = 200; sy = 270;
    const fo = (1 - clamp01((fallY - 700) / 700)).toFixed(2);
    $('worldMtn').setAttribute('opacity', fo); $('worldBack').setAttribute('opacity', fo); $('worldFront').setAttribute('opacity', fo);
  } else if (mode === 'sky' || mode === 'space') {
    wy = APEX[1] - 200 - (L - FLOAT_LIFT) * U * 1.6; wx = 200; ay = -60; s = .95; sx = 200; sy = 300;
  } else if (mode === 'summit') {
    wx = APEX[0]; wy = APEX[1] - 60; ax = 5; ay = -127; s = 1.1; sx = 205; sy = 250;
  } else {
    const yy = -Math.min(L, EVEREST_LIFT) * U; wx = ridgeX(yy - 70) - 20; wy = yy; sx = 175; sy = 380;
  }
  $('climber').setAttribute('transform', `translate(${wx.toFixed(1)},${wy.toFixed(1)}) scale(${s}) translate(${-ax},${-ay})`);
  $('world').setAttribute('transform', `translate(${(sx - wx).toFixed(1)},${(sy - wy + camOff).toFixed(1)})`);
  const words = ['Feeling strong', 'Breathing harder', 'Struggling in the thin air', 'Gasping for oxygen!'];
  let c;
  if (mode === 'fall') c = 'Out of oxygen! Aaaaaaah!';
  else if (mode === 'celebrate') c = L >= FLOAT_LIFT ? 'Flying the flag up here!' : 'Flag planted! What a climb!';
  else if (mode === 'summit') c = 'Hold on!!';
  else if (mode === 'sky' || mode === 'space') { const list = HIGH_CAPS.filter(z => L >= z[0]).pop()[1]; c = list[Math.floor(Date.now() / 3200) % list.length]; if (sev >= 2 && Math.floor(Date.now() / 3200) % 2) c = 'Tank running low!'; }
  else if (L < CLOUD_BASE && sev < 2) c = sev ? 'Soaked, but climbing' : 'Climbing through the storm';
  else c = words[sev];
  $('caption').textContent = c;
}
const HIGH_CAPS = [
  [50, ['Whoooosh!', 'Wave to the passengers!', 'Mind the jet engines', 'Higher than the planes']],
  [60, ['Up with the weather balloons', 'The sky\u2019s turning dark', 'Look, the Earth is curving!', 'Ears popping\u2026']],
  [72, ['Welcome to space!', 'Aurora views!', 'Overtaking a rocket', 'That\u2019s a long way down']],
  [86, ['Floating past the space station', 'Mind the space junk', 'Who lost a sock up here?', 'Sunrise every 90 minutes']],
  [105, ['One small step\u2026', 'Moonwalking', 'Hello, astronaut!', 'Earth looks tiny from here']],
  [130, ['Galactic sightseeing', 'Dodging comets', 'Billions of stars', 'Was that a black hole?']],
  [160, ['Take me to your leader', 'We come in peace!', 'Alien high-five!', 'Beam me up!']]
];
setInterval(() => { const m = $('stage').dataset.mode; if (m === 'sky' || m === 'space') paintClimber(); }, 3200);
function animateTo(target, dur) {
  const from = shownLift;
  if (reduceMotion || from === target) { shownLift = target; paintWorld(target); return; }
  const t0 = performance.now();
  return new Promise(res => {
    function step(now) {
      const t = Math.min(1, (now - t0) / dur), e = t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      shownLift = from + (target - from) * e; paintWorld(shownLift);
      if (t < 1) requestAnimationFrame(step); else { shownLift = target; paintWorld(target); res(); }
    }
    requestAnimationFrame(step);
  });
}
window.addEventListener('resize', () => paintWorld(shownLift));
let fallY = 0, fallRAF = null;
function startFall() {
  document.body.classList.add('falling');
  if (fallRAF || reduceMotion) return;
  const t0 = performance.now();
  const step = now => { const t = (now - t0) / 1000; fallY = t < 1.5 ? 180 * t * t : 405 + 540 * (t - 1.5); paintClimber(shownLift); fallRAF = requestAnimationFrame(step); };
  fallRAF = requestAnimationFrame(step);
}
function stopFall() { cancelAnimationFrame(fallRAF); fallRAF = null; fallY = 0; document.body.classList.remove('falling'); ['worldMtn','worldBack','worldFront'].forEach(id => $(id).setAttribute('opacity', 1)); }

/* ---------- Oxygen + effects ---------- */
function paintO2() {
  const v = Math.max(0, Math.round(S.o2)), low = v <= 25 && v > 0;
  $('o2label').textContent = `O\u2082 ${v}%`; $('o2label').classList.toggle('low', low);
  $('o2fill').style.width = v + '%'; $('o2bar').classList.toggle('low', low); $('o2bar').setAttribute('aria-valuenow', v);
  const tb = document.querySelector('.tankbtn'); if (tb) { tb.querySelector('.tk-fill').style.width = v + '%'; tb.classList.toggle('low', low); }
  document.body.classList.toggle('lowair', low && S.started && !S.done);
  $('thin').textContent = S.lift >= SPACE_LIFT ? `No air up here. Every answer costs ${VACUUM_COST}% oxygen.`
    : S.lift >= EVEREST_LIFT ? `Thin air. Every answer costs ${THIN_AIR_COST}% oxygen.` : '';
  paintWorld(shownLift);
}
function tempFace(f, ms) { faceOverride = f; paintClimber(); clearTimeout(faceTimer); faceTimer = setTimeout(() => { faceOverride = null; paintClimber(); }, ms); }
function pulseClass(el, cls, ms) { el.classList.remove(cls); void el.getBoundingClientRect(); el.classList.add(cls);
  clearTimeout(el['_t_' + cls]); el['_t_' + cls] = setTimeout(() => el.classList.remove(cls), ms); }
function o2pop(text) {
  const bar = $('o2bar').getBoundingClientRect(), el = document.createElement('div');
  el.className = 'o2pop'; el.textContent = text;
  el.style.left = Math.min(window.innerWidth - 70, Math.max(70, bar.left + bar.width / 2)) + 'px';
  el.style.top = (bar.bottom + 8) + 'px';
  document.body.appendChild(el); setTimeout(() => el.remove(), 2200);
  pulseClass($('o2bar'), 'hit', 700);
}
function pop(text, cls) {
  const el = document.createElement('div'); el.className = 'pop ' + (cls || ''); el.textContent = text;
  const sr = $('stage').getBoundingClientRect(), cr = $('climber').getBoundingClientRect();
  el.style.left = Math.max(110, Math.min(sr.width - 110, cr.left - sr.left + cr.width / 2)) + 'px';
  el.style.top = Math.max(40, cr.top - sr.top - 6) + 'px';
  $('fxlayer').appendChild(el); setTimeout(() => el.remove(), 1700);
}
function showBanner(text) { Sound.chime(); const b = $('banner'); b.textContent = text; b.classList.remove('show'); void b.offsetWidth; b.classList.add('show'); }
const STAMP = {
  common:   ['Tourist trail', 'Gift shop\u2019s that way'],
  uncommon: ['Scramble', 'Hands, feet and hope'],
  rare:     ['Clean ascent', 'Smooth operator'],
  veryrare: ['Overhang', 'Hanging in there'],
  ultra:    ['Free solo', 'No rope. No fear.'],
  gem:      ['First ascent', 'Nobody\u2019s been here before'],
  stall:    ['Stalled', 'Frozen on the wall']
};
const GEM_SVG = '<svg viewBox="0 0 120 100"><path d="M24 8 L96 8 L118 36 L60 98 L2 36 Z" fill="#2FE3FF"/><path d="M24 8 L44 36 L2 36 Z" fill="#8CF2FF"/><path d="M96 8 L76 36 L118 36 Z" fill="#14B6E0"/><path d="M44 36 L76 36 L60 98 Z" fill="#62EAFF"/><path d="M2 36 L44 36 L60 98 Z" fill="#1FC9EE"/><path d="M76 36 L118 36 L60 98 Z" fill="#0E9CC8"/><path d="M24 8 L60 8 L44 36 Z M60 8 L96 8 L76 36 Z" fill="#B8F8FF"/><path d="M60 8 L44 36 L76 36 Z" fill="#E6FDFF"/><path d="M30 -2 l3 7 l7 3 l-7 3 l-3 7 l-3 -7 l-7 -3 l7 -3 Z M104 50 l2.5 5 l5 2.5 l-5 2.5 l-2.5 5 l-2.5 -5 l-5 -2.5 l5 -2.5 Z" fill="#fff"/></svg>';
function stamp(tier, lift) {
  const s = STAMP[tier]; if (!s) return;
  const el = document.createElement('div');
  el.className = 'stamp s-' + tier;
  el.style.setProperty('--r', (Math.random() * 16 - 8).toFixed(1) + 'deg');
  el.innerHTML = (tier === 'gem' ? GEM_SVG : '') + `<div class="in"><small>THE SUMMIT \u00b7 DAY ${DAY.num}</small><b>${s[0]}</b><i>${s[1]}</i>${lift ? `<em>+${lift}</em>` : ''}</div>`;
  document.body.appendChild(el); setTimeout(() => el.remove(), 2600);
}
function slashTape() {
  const el = document.createElement('div'); el.className = 'slash';
  el.innerHTML = `<div class="tape t1"></div><div class="tape t2"></div><div class="plate"><b>FALSE SUMMIT! \u22125</b><i>Everyone thought of that. Climb back down!</i></div>`;
  document.body.appendChild(el); setTimeout(() => el.remove(), 2900);
  setTimeout(() => { if (!reduceMotion) pulseClass($('app'), 'thud', 600); }, 220);
  pulseClass($('stage'), 'fog', 2600); tempFace('ok', 2600);
}
function oops() {
  Sound.wrong();
  if (!reduceMotion) pulseClass($('app'), 'shake', 450);
  pulseClass($('flash'), 'on', 450); pulseClass($('stage'), 'oops', 1300); tempFace('gasp', 1300);
  o2pop(`\u2212${WRONG_COST}% O\u2082`);
}
async function pitchCard(i) {
  Sound.whoosh();
  $('pn').textContent = `Pitch ${i + 1} of ${DAY.prompts.length}`;
  $('pq').textContent = DAY.prompts[i].q;
  const c = $('pitchcard'); c.classList.remove('show'); void c.offsetWidth; c.classList.add('show');
  await sleep(1250);
}

/* ---------- Panel ---------- */
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const panelOut = () => { $('panel').classList.add('out'); return sleep(320); };
const panelIn = () => { $('panel').classList.remove('out'); };

const PICK = '<svg class="pick" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.6 5 L13.2 5 L15 23 L12.4 23 Z" fill="#9A5B2E"/><path d="M11.1 8.5 h2.4 v2.4 h-2.4z M12 16 h2.4 v1.6 h-2.4z" fill="#3A2416"/><path d="M.8 7.2 Q12 1 23.4 4.2 L22.8 7 Q13 4.8 1.8 9.4 Z" fill="#C9D3E0"/><path d="M.8 7.2 Q12 1 23.4 4.2 L23.3 5 Q12 2.4 1.2 8 Z" fill="#fff"/><path d="M9.6 3.4 h5 v4 h-5z" fill="#7C8799"/></svg>';
const AXE = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 1.5 H10 A4.5 4.5 0 0 1 14.5 6 V10 A4.5 4.5 0 0 1 10 14.5 H6 A3.5 3.5 0 0 1 2.5 11 V5 A3.5 3.5 0 0 1 6 1.5 Z" fill="none" stroke="#fff" stroke-width="2"/><path d="M5.2 4.5 L5.2 11.5" stroke="#8E1420" stroke-width="2.6"/><path d="M5.2 4.8 L6.4 11.2" stroke="#fff" stroke-width="1.5"/></svg>';
function showSplash() {
  const sp = $('splash'); sp.hidden = false; sp.classList.remove('gone');
  camOff = SPLASH_CAM; paintClimber(); document.body.classList.add('splash');
  $('panel').classList.add('out');
  $('startbtn').onclick = async () => {
    if (busy) return; busy = true; S.started = true; save();
    sp.classList.add('gone'); await sleep(350); sp.hidden = true;
    await camTo(SPLASH_CAM * 0.93, 1300);
    await bigStrike();
    document.body.classList.remove('splash');
    await sleep(350);
    $('stage').classList.remove('closeup');
    await pitchCard(S.idx); busy = false; render(); panelIn();
  };
  $('startbtn').focus({ preventScroll: true });
}
let timer = null, tLeft = TIME_LIMIT;
const CIRC = 2 * Math.PI * 16;
function drawTimer() {
  const t = $('timer'); if (!t) return;
  if (tLeft <= 5 && tLeft > 0 && timer) Sound.tick();
  t.querySelector('span').textContent = Math.max(0, tLeft);
  t.querySelector('.arc').style.strokeDashoffset = (CIRC * (1 - tLeft / TIME_LIMIT)).toFixed(1);
  t.classList.toggle('warn', tLeft <= 10 && tLeft > 5); t.classList.toggle('crit', tLeft <= 5);
}
function stopTimer() { clearInterval(timer); timer = null; }
let pitchStart = Date.now();
function startTimer() {
  stopTimer(); tLeft = TIME_LIMIT; drawTimer(); pitchStart = Date.now();
  timer = setInterval(() => { if (busy) return; tLeft--; drawTimer(); if (tLeft <= 0) { stopTimer(); climbResult('stall', 'Out of time'); } }, 1000);
}

function render() {
  const P = $('panel');
  paintO2();
  if (!S.started) { showSplash(); return; }
  if (S.done) { stopTimer(); return renderRecap(P); }
  const p = DAY.prompts[S.idx];
  if (S.phase === 'result' && S.lastResult) { stopTimer(); return renderResult(P, p); }
  P.innerHTML = `<div class="qrow"><span class="count">${PICK}Pitch ${S.idx + 1}/${DAY.prompts.length}</span><h2 class="prompt">${esc(p.q)}</h2>
      <div class="timer" id="timer" aria-label="Seconds left"><svg viewBox="0 0 40 40"><circle class="trk" cx="20" cy="20" r="16" fill="none" stroke-width="4"/><circle class="arc" cx="20" cy="20" r="16" fill="none" stroke-width="4" stroke-dasharray="${CIRC.toFixed(1)}" stroke-dashoffset="0"/></svg><span>${TIME_LIMIT}</span></div></div>
    <form class="entry" id="f" autocomplete="off" onsubmit="return false">
      <label class="sr" for="ans">Your answer</label>
      <input id="ans" type="text" autocapitalize="off" spellcheck="false" placeholder="Type an answer">
      <span class="tankwrap"><button id="go" type="submit" class="tankbtn"><span class="tk-fill"></span><span class="tk-shine"></span><span class="tk-label">CLIMB</span></button></span>
    </form>
    <p class="msg" id="msg"></p>`;
  paintO2();
  const inp = $('ans'); inp.focus({ preventScroll: true });
  $('f').addEventListener('submit', () => submit(inp.value));
  startTimer();
}

async function submit(raw) {
  if (busy) return;
  const msg = $('msg');
  const r = lookup(INDEX[S.idx], raw);
  if (!r) return;
  if (r.suggest) {
    msg.className = 'msg';
    msg.innerHTML = `Did you mean <button class="link" id="sug">${esc(r.suggest.display)}</button>? No oxygen lost.`;
    $('sug').onclick = () => submit(r.suggest.display);
    return;
  }
  if (r.none) {
    S.o2 -= WRONG_COST; S.wrong = (S.wrong || 0) + 1; oops();
    if (S.o2 <= 0) { S.o2 = 0; S.results.push({ q: DAY.prompts[S.idx].q, answer: raw.trim(), tier: 'none', emoji: '\ud83e\udd76' });
      S.outOfAir = true; S.done = true; finishRun(); stopTimer(); save(); paintClimber(); startFall(); render(); panelIn(); return; }
    save(); paintO2();
    msg.className = 'msg bad'; msg.textContent = `\u201c${raw.trim()}\u201d isn\u2019t on today\u2019s map. \u2212${WRONG_COST}% oxygen.`;
    $('ans').select(); return;
  }
  climbResult(r.match.tier, r.match.display);
}

async function climbResult(tier, display) {
  if (busy) return;
  busy = true; stopTimer();
  const info = TIER_INFO[tier], before = S.lift;
  let o2d = info.o2;
  if (before >= SPACE_LIFT) o2d = Math.min(o2d, -VACUUM_COST); else if (before >= EVEREST_LIFT) o2d = Math.min(o2d, -THIN_AIR_COST);
  if (tier === 'gem') o2d = 0;
  const after = Math.max(0, Math.min(MAX_LIFT, before + info.lift));
  let emoji;
  if (tier === 'stall') emoji = '\u23f1\ufe0f';
  else if (tier === 'false') emoji = '\ud83c\udf2b\ufe0f';
  else if (tier === 'gem') emoji = '\ud83d\udc8e';
  else if (before < EVEREST_LIFT && after >= EVEREST_LIFT) emoji = '\ud83c\udfd4\ufe0f';
  else if (after >= SPACE_LIFT) emoji = '\ud83d\ude80';
  else if (after >= EVEREST_LIFT) emoji = '\ud83c\udf2a\ufe0f';
  else if (before < CLOUD_TOP && after >= CLOUD_TOP) emoji = '\u2601\ufe0f';
  else emoji = (tier === 'common' || tier === 'uncommon') ? '\ud83e\udd7e' : '\ud83e\uddd7';
  S.lift = after; S.o2 = Math.min(100, S.o2 + o2d);
  const bonus = (tier !== 'stall' && tier !== 'false') ? bonusFor(S.idx, display) : null;
  const res = { q: DAY.prompts[S.idx].q, answer: display, tier, lift: after - before, o2d, emoji, bonus };
  collectTier(tier);
  const bonusNew = bonus ? collectBonus(S.idx, bonus, display) : false;
  const took = (Date.now() - pitchStart) / 1000;
  if (tier === 'stall') award('frozen');
  else {
    if (took <= 5) { award('quick'); S.quick = (S.quick || 0) + 1; if (S.quick >= 3) award('lightning'); }
    if (tLeft <= 1) award('buzzer');
  }
  if (tier === 'gem') { award('gem'); S.gems = (S.gems || 0) + 1; if (S.gems >= 3) award('triplegem'); }
  if (tier === 'false') { S.falses = (S.falses || 0) + 1; if (S.falses >= 3) award('fogbound'); }
  if (after >= EVEREST_LIFT) award('summit');
  if (after >= SPACE_LIFT) award('space');
  if (after >= 105) award('moon');
  if (after >= 160) award('aliens');
  S.results.push(res); S.lastResult = res; S.phase = 'result';
  if (S.o2 <= 0) { S.o2 = 0; S.outOfAir = true; }
  save();
  await panelOut();
  paintO2();
  const p = POWER[tier] || 0, sc = $('stage');
  sc.dataset.power = p;
  if (tier === 'false') slashTape(); else stamp(tier, info.lift);
  Sound.tier(tier); if (tier !== 'false') setTimeout(() => Sound.slap(), 60);
  if (bonus) setTimeout(() => bonusStamp(bonus, display, bonusNew), 1500);
  if (tier === 'stall') { if (!reduceMotion) pulseClass($('app'), 'shake', 450); pulseClass($('flash'), 'on', 450); pulseClass(sc, 'oops', 650); tempFace('gasp', 1200); }
  else if (p >= 3) tempFace('happy', 2200);
  if (after !== before) sc.classList.add('moving');
  if (o2d < 0) o2pop(`\u2212${-o2d}% O\u2082`);
  const zb = zoneIndex(before), za = zoneIndex(after);
  if (za > zb && ZONES[za].banner) setTimeout(() => showBanner(ZONES[za].banner), 900);
  else if (before < CLOUD_TOP && after >= CLOUD_TOP) setTimeout(() => showBanner('You broke through the clouds!'), 900);
  const dur = 1400 + Math.min(1600, info.lift * 50);
  await animateTo(S.lift, after > before ? dur : after < before ? 1300 : 600);
  sc.classList.remove('moving');
  if (S.outOfAir) { paintClimber(); startFall(); }
  if (after > before) pulseClass($('alt'), 'punch', 700);
  await sleep(bonus ? 1700 : tier === 'false' ? 900 : 250);
  busy = false; render(); panelIn();
}

function fsNames(p) { return p.t.false.split(';').map(x => cap(x.split('|')[0].trim())).filter(Boolean); }

function renderResult(P, p) {
  const r = S.lastResult, info = TIER_INFO[r.tier];
  const last = S.idx >= DAY.prompts.length - 1 || S.outOfAir;
  const o2txt = r.o2d > 0 ? `<span class="pos">+${r.o2d}% O\u2082</span>` : r.o2d < 0 ? `<span class="neg">\u2212${-r.o2d}% O\u2082</span>` : '';
  P.innerHTML = `<div class="verdictrow"><span class="chip c-${r.tier}">${info.label}</span><span class="ans">${esc(r.answer)}</span><span class="deltas">${r.lift < 0 ? '\u2212' + (-r.lift) : '+' + r.lift} ${o2txt}</span></div>
    ${r.bonus ? `<p class="bonusline"><span class="dot" style="background:${BONUS_CATS[r.bonus.cat].color}">${BONUS_CATS[r.bonus.cat].icon.replace('class="ico"', '')}</span>Bonus sticker: ${BONUS_CATS[r.bonus.cat].name} <span class="why">${esc(r.bonus.why)}</span></p>` : ''}
    <p class="line">${info.line}</p>
    <p class="fs"><b>False summit: ${fsNames(p).map(esc).join(', ')}.</b> ${esc(p.joke)}</p>
    ${S.outOfAir ? '<p class="msg bad">He\u2019s out of oxygen and falling! The climb ends here.</p>' : ''}
    <button id="next" class="wide pitchbtn">${last ? 'See your ascent' : 'Next pitch'}</button>`;
  const btn = $('next'); btn.focus({ preventScroll: true });
  btn.onclick = async () => {
    if (busy) return; busy = true;
    await panelOut();
    S.lastResult = null; S.phase = 'ask';
    if (last) { S.done = true; finishRun(); paintBest(); } else { S.idx++; save(); await pitchCard(S.idx); }
    save(); busy = false; render(); panelIn();
  };
}

function shareText() {
  const route = '\u26fa' + S.results.map(r => r.emoji).join('') + (S.outOfAir && S.results[S.results.length - 1].emoji !== '\ud83e\udd76' ? '\ud83e\udd76' : '');
  return `THE SUMMIT \u00b7 Day ${DAY.num} \u00b7 ${DAY.theme}\n${route}\n${fmtAlt(altitude(S.lift))} \u00b7 ${zoneName(S.lift)} \u00b7 O\u2082 ${Math.max(0, Math.round(S.o2))}%\n${location.origin}${location.pathname}`;
}
const GEM_CLUES = DAY.prompts.map(p => p.clue || '\u2753');
function resultSticker() {
  const el = $('resultsticker'), route = S.results.map(r => r.emoji).join('');
  el.innerHTML = `<div class="rs-in"><small>THE SUMMIT \u00b7 DAY ${DAY.num} \u00b7 ${esc(DAY.theme).toUpperCase()}</small>
    <b>${fmtAlt(altitude(S.lift))}</b><span class="rs-zone">${esc(zoneName(S.lift))}</span>
    <div class="rs-row"><span><em>O\u2082</em>${Math.max(0, Math.round(S.o2))}%</span><span><em>Score</em>${S.lift}</span><span><em>Pitches</em>${S.results.length}/${DAY.prompts.length}</span></div>
    <div class="rs-route">\u26fa${route}</div><i>${S.outOfAir ? 'Out of oxygen. Next time!' : best && S.lift >= best ? 'New personal best!' : 'Ascent complete'}</i></div>`;
  if (!el.classList.contains('show')) { el.classList.add('show'); setTimeout(() => Sound.slap(), 250); }
}
function renderRecap(P) {
  document.body.classList.add('finished'); resultSticker();
  const short = q => cap(q.replace(/^Name (a|an) /i, '').replace(/^type of /i, '').replace(/ \(.*\)$/, ''));
  const rows = DAY.prompts.map((p, i) => { const r = S.results[i];
    if (!r) return `<li class="dim"><span class="rq">${esc(p.q)}</span><span class="ra">Not reached</span><span></span><span class="rp"></span></li>`;
    if (r.tier === 'none') return `<li><span class="rq">${esc(p.q)}</span><span class="ra">${esc(r.answer)}</span><span class="chip c-stall">Out of air</span><span class="rp">0</span></li>`;
    const pts = r.lift < 0 ? '\u2212' + (-r.lift) : '+' + r.lift;
    return `<li><span class="rq">${esc(p.q)}</span><span class="ra">${esc(r.answer)}</span><span class="chip c-${r.tier}">${TIER_INFO[r.tier].label}</span><span class="rp">${pts}</span></li>`; }).join('');
  P.innerHTML = `<div class="recap compact">
    <ul class="rlist">${rows}</ul>
    <div class="endrow"><button id="bookbtn" class="pitchbtn">Sticker Book</button><button id="copy" class="quiet">Copy result</button><button id="reset" class="reascend">${PICK}Reascend!!</button></div>
    <pre class="share sr" id="share">${esc(shareText())}</pre>
    ${(window.SUMMIT_CONFIG || {}).coffee ? `<a class="coffeebtn" href="${esc(window.SUMMIT_CONFIG.coffee)}" target="_blank" rel="noopener"><span class="cup">\u2615</span>Enjoying it? Buy me a coffee</a>` : ''}
    </div>`;
  $('bookbtn').onclick = openBook;
  $('copy').onclick = async () => {
    try { await navigator.clipboard.writeText(shareText()); $('copy').textContent = 'Copied'; }
    catch (e) { const range = document.createRange(); range.selectNodeContents($('share')); const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range); $('copy').textContent = 'Selected, press copy'; }
  };
  $('reset').onclick = async () => {
    if (busy) return; busy = true;
    document.body.classList.remove('finished'); $('resultsticker').classList.remove('show');
    S = fresh(); try { localStorage.removeItem(KEY); } catch (e) {}
    document.body.classList.remove('lowair'); stopFall(); paintBest(); confetti(false);
    $('panel').classList.add('out');
    await animateTo(0, 1500);
    const bo = $('blackout'); bo.classList.remove('lift'); bo.classList.add('on');
    await sleep(1100);
    busy = false; render();
    bo.classList.remove('on'); void bo.offsetWidth; bo.classList.add('lift');
  };
}

/* ---------- Bonus stickers (keyed by each answer's main name) ---------- */
const BONUS_CATS = {
  sport:  { name: 'Sports Fan',        color: '#17A35C', icon: '<svg class="ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#fff"/><path d="M12 6 L16.5 9.3 L14.8 14.6 L9.2 14.6 L7.5 9.3 Z" fill="#141A2E"/><path d="M12 2 V6 M16.5 9.3 L21.4 8 M14.8 14.6 L17.8 19 M9.2 14.6 L6.2 19 M7.5 9.3 L2.6 8" stroke="#141A2E" stroke-width="1.6"/></svg>' },
  celeb:  { name: 'Star Spotted',      color: '#C98600', icon: '<svg class="ico" viewBox="0 0 24 24"><path d="M1 9 H23 V11 H21.5 Q21 17 16 17 Q12.6 17 12.4 12 H11.6 Q11.4 17 8 17 Q3 17 2.5 11 H1 Z" fill="#fff"/></svg>' },
  screen: { name: 'Screen Time',       color: '#6B3FE0', icon: '<svg class="ico" viewBox="0 0 24 24"><path d="M12 1.5 L15 8.6 L22.6 9.2 L16.8 14.2 L18.6 21.7 L12 17.7 L5.4 21.7 L7.2 14.2 L1.4 9.2 L9 8.6 Z" fill="#fff"/></svg>' },
  wild:   { name: 'Weird & Wonderful', color: '#FF3E9E', icon: '<svg class="ico" viewBox="0 0 24 24"><path d="M14 1 L4 14 L11 14 L9 23 L20 9 L13 9 Z" fill="#fff"/></svg>' },
};
const BONUS = DAY.prompts.map(p => { const o = {}; Object.entries(p.bonus || {}).forEach(([k, v]) => { if (BONUS_CATS[v[0]]) o[norm(k)] = v; }); return o; });
const bonusFor = (i, display) => { const b = BONUS[i] && BONUS[i][norm(display)]; return b ? { key: norm(display), cat: b[0], why: b[1] } : null; };

/* ---------- Sticker collection (kept across days) ---------- */
const BOOK_KEY = 'summit-stickers';
let BOOK = { tiers: {}, bonus: {}, feats: {} };
try { BOOK = Object.assign({ tiers: {}, bonus: {}, feats: {} }, JSON.parse(localStorage.getItem(BOOK_KEY) || '{}')); } catch (e) {}
function saveBook() { try { localStorage.setItem(BOOK_KEY, JSON.stringify(BOOK)); } catch (e) {} }
function collectTier(t) { BOOK.tiers[t] = (BOOK.tiers[t] || 0) + 1; saveBook(); }
function collectBonus(i, b, display) {
  const id = `${DAY.num}:${i}:${b.key}`, isNew = !BOOK.bonus[id];
  if (isNew) BOOK.bonus[id] = { cat: b.cat, name: display, why: b.why, day: DAY.num, q: DAY.prompts[i].q };
  saveBook(); return isNew;
}
const BONUS_ART = {sport: '<svg viewBox="0 0 200 200"><defs><clipPath id="ballc"><circle cx="100" cy="100" r="86"/></clipPath></defs><circle cx="100" cy="100" r="88" fill="#fff"/><g clip-path="url(#ballc)"><path d="M100.0 72.0 L126.6 91.3 L116.5 122.7 L83.5 122.7 L73.4 91.3 Z" fill="#141A2E"/><path d="M100.0 72.0 L100.0 42.0" stroke="#141A2E" stroke-width="5"/><path d="M114.1 0.6 L122.8 27.4 L100.0 44.0 L77.2 27.4 L85.9 0.6 Z" fill="#141A2E"/><path d="M100.0 42.0 L155.2 82.1" stroke="#141A2E" stroke-width="5" opacity=".35"/><path d="M126.6 91.3 L155.2 82.1" stroke="#141A2E" stroke-width="5"/><path d="M198.9 82.7 L176.1 99.3 L153.3 82.7 L162.0 55.9 L190.2 55.9 Z" fill="#141A2E"/><path d="M155.2 82.1 L134.1 146.9" stroke="#141A2E" stroke-width="5" opacity=".35"/><path d="M116.5 122.7 L134.1 146.9" stroke="#141A2E" stroke-width="5"/><path d="M147.0 188.7 L124.2 172.1 L132.9 145.3 L161.1 145.3 L169.8 172.1 Z" fill="#141A2E"/><path d="M134.1 146.9 L65.9 146.9" stroke="#141A2E" stroke-width="5" opacity=".35"/><path d="M83.5 122.7 L65.9 146.9" stroke="#141A2E" stroke-width="5"/><path d="M30.2 172.1 L38.9 145.3 L67.1 145.3 L75.8 172.1 L53.0 188.7 Z" fill="#141A2E"/><path d="M65.9 146.9 L44.8 82.1" stroke="#141A2E" stroke-width="5" opacity=".35"/><path d="M73.4 91.3 L44.8 82.1" stroke="#141A2E" stroke-width="5"/><path d="M9.8 55.9 L38.0 55.9 L46.7 82.7 L23.9 99.3 L1.1 82.7 Z" fill="#141A2E"/><path d="M44.8 82.1 L100.0 42.0" stroke="#141A2E" stroke-width="5" opacity=".35"/></g><circle cx="100" cy="100" r="88" fill="none" stroke="#141A2E" stroke-width="7"/><path d="M48 60 Q62 36 90 28" stroke="#fff" stroke-width="7" fill="none" opacity=".7" stroke-linecap="round"/></svg>',screen: '<svg viewBox="0 0 200 200"><rect x="12" y="12" width="176" height="176" rx="14" fill="#3A2C52"/><rect x="20" y="20" width="160" height="160" rx="10" fill="none" stroke="#5B4880" stroke-width="3"/><path d="M100.0 26.0 L120.0 78.5 L176.1 81.3 L132.3 116.5 L147.0 170.7 L100.0 140.0 L53.0 170.7 L67.7 116.5 L23.9 81.3 L80.0 78.5 Z" fill="#F2789F" stroke="#E8B33A" stroke-width="8" stroke-linejoin="round"/><circle cx="100" cy="108" r="20" fill="#E8B33A"/><path d="M100.0 95.0 L103.5 103.1 L112.4 104.0 L105.7 109.9 L107.6 118.5 L100.0 114.0 L92.4 118.5 L94.3 109.9 L87.6 104.0 L96.5 103.1 Z" fill="#3A2C52"/></svg>',celeb: '<svg viewBox="0 0 200 200"><defs><linearGradient id="vipg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFE27A"/><stop offset="1" stop-color="#E39A00"/></linearGradient></defs><path d="M62 0 L96 40 M138 0 L104 40" stroke="#E31B23" stroke-width="12"/><rect x="86" y="30" width="28" height="22" rx="4" fill="#9AA6B8"/><rect x="34" y="44" width="132" height="150" rx="12" fill="url(#vipg)"/><rect x="80" y="56" width="40" height="9" rx="4.5" fill="#8A5A00"/><path d="M40 100 H160 V106 H154 Q152 132 128 132 Q106 132 104 108 H96 Q94 132 72 132 Q48 132 46 106 H40 Z" fill="#141A2E"/><path d="M58 108 l14 -4 M116 108 l14 -4" stroke="#fff" stroke-width="4" opacity=".6" stroke-linecap="round"/><text x="100" y="178" text-anchor="middle" font-family="Russo One, sans-serif" font-size="36" fill="#141A2E">VIP</text></svg>',wild: '<svg viewBox="0 0 200 200"><path d="M192.0 100.0 L161.0 125.3 L165.1 165.1 L125.3 161.0 L100.0 192.0 L74.7 161.0 L34.9 165.1 L39.0 125.3 L8.0 100.0 L39.0 74.7 L34.9 34.9 L74.7 39.0 L100.0 8.0 L125.3 39.0 L165.1 34.9 L161.0 74.7 Z" fill="#FFC21A"/><path d="M192.0 100.0 L161.0 125.3 L165.1 165.1 L125.3 161.0 L100.0 192.0 L74.7 161.0 L34.9 165.1 L39.0 125.3 L8.0 100.0 L39.0 74.7 L34.9 34.9 L74.7 39.0 L100.0 8.0 L125.3 39.0 L165.1 34.9 L161.0 74.7 Z" fill="#FF3E9E" transform="translate(100 100) scale(.84) rotate(11) translate(-100 -100)"/><circle cx="100" cy="98" r="44" fill="#fff" stroke="#141A2E" stroke-width="6"/><circle cx="112" cy="106" r="19" fill="#141A2E"/><circle cx="118" cy="99" r="6" fill="#fff"/><path d="M58 64 Q80 44 104 50" stroke="#141A2E" stroke-width="6" fill="none" stroke-linecap="round"/></svg>'};
function bonusStampHTML(b, display, isNew) {
  const c = BONUS_CATS[b.cat];
  return `<div class="bart">${BONUS_ART[b.cat]}</div><div class="ribbon" style="--bc:${c.color}"><small>BONUS STICKER</small><b>${c.name}</b><span class="ans">${esc(display)}</span><i>${esc(b.why)}</i></div>${isNew ? '<span class="new">NEW!</span>' : ''}`;
}
function bonusStamp(b, display, isNew) {
  Sound.sticker();
  const el = document.createElement('div');
  el.className = 'stamp s-bonus'; el.style.setProperty('--r', (Math.random() * 14 - 7).toFixed(1) + 'deg');
  el.innerHTML = bonusStampHTML(b, display, isNew);
  document.body.appendChild(el); setTimeout(() => el.remove(), 2700);
}

/* ---------- Confetti ---------- */
function confetti(on, zeroG) {
  if (on && !document.body.classList.contains('party')) Sound.fanfare();
  const box = $('confetti');
  if (on && !box.childElementCount) {
    const cols = ['#FF2D45', '#FFC21A', '#1E6BFF', '#19D98A', '#FF3E9E', '#6B3FE0', '#FFFFFF'];
    let h = '';
    for (let i = 0; i < 90; i++) { const d = (2.6 + Math.random() * 2.4).toFixed(2);
      h += `<span class="cf" style="left:${(Math.random() * 100).toFixed(1)}%;background:${cols[i % cols.length]};--d:${d}s;animation-duration:${d}s;animation-delay:-${(Math.random() * 5).toFixed(2)}s;width:${6 + (i % 3) * 3}px;height:${10 + (i % 4) * 2}px"></span>`; }
    box.innerHTML = h;
  }
  document.body.classList.toggle('party', !!on); document.body.classList.toggle('zerog', !!zeroG);
}

/* ---------- Sticker book ---------- */
const BOOK_TIERS = ['common', 'uncommon', 'rare', 'veryrare', 'ultra', 'gem', 'false', 'stall'];
function miniTier(t) {
  if (t === 'false') return `<div class="stamp s-common" style="--r:-6deg"><div class="in" style="background:repeating-linear-gradient(-45deg,#141A2E 0 12px,#FFC21A 12px 24px)"><b style="background:#FFC21A;color:#141A2E;padding:2px 8px">False summit</b></div></div>`;
  const s = STAMP[t];
  return `<div class="stamp s-${t}" style="--r:${(t.length % 3 - 1) * 5}deg">${t === 'gem' ? GEM_SVG : ''}<div class="in"><small>THE SUMMIT</small><b>${s[0]}</b><i>${s[1]}</i></div></div>`;
}
// A short clue for a locked bonus sticker: its reason, with the answer itself blanked out.
function maskHint(key, why) {
  let h = why || '';
  const words = key.split(' ').filter(w => w.length > 2).sort((a, b) => b.length - a.length);
  [key].concat(words).forEach(w => { h = h.replace(new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + "[a-z']*", 'gi'), '____'); });
  return h.replace(/(____\s*)+/g, '____ ');
}
function openBook() {
  const tierSlots = BOOK_TIERS.map(t => { const n = BOOK.tiers[t] || 0, name = t === 'false' ? 'False summit' : STAMP[t][0];
    return n ? `<div class="slot got"><span class="ct">\u00d7${n}</span><div class="art">${miniTier(t)}</div><span class="nm">${name}</span></div>`
             : `<div class="slot locked"><span class="q">?</span><span class="nm">${name}</span></div>`; }).join('');
  const totalToday = BONUS.reduce((a, o) => a + Object.keys(o).length, 0);
  const gotToday = Object.values(BOOK.bonus).filter(b => b.day === DAY.num).length;
  let sections = '';
  for (const cat in BONUS_CATS) {
    const c = BONUS_CATS[cat];
    const todays = []; BONUS.forEach((o, i) => Object.entries(o).forEach(([k, v]) => { if (v[0] === cat) todays.push({ id: `${DAY.num}:${i}:${k}`, i, hint: maskHint(k, v[1]) }); }));
    const got = Object.entries(BOOK.bonus).filter(([id, b]) => b.cat === cat);
    const slots = todays.map(({ id, i, hint }) => { const b = BOOK.bonus[id];
      return b ? `<div class="slot got"><div class="art"><div class="stamp s-bonus" style="--r:-5deg">${bonusStampHTML(b, b.name, false)}</div></div><span class="nm">${esc(b.name)}</span></div>`
               : `<div class="slot locked" data-hint="${esc(hint)}" data-q="${esc(DAY.prompts[i].q)}"><span class="q">?</span><span class="nm">${esc(DAY.prompts[i].q.replace(/^Name (a|an) /i, '').replace(/^type of /i, ''))}</span></div>`; }).join('')
      + got.filter(([id, b]) => b.day !== DAY.num).map(([id, b]) => `<div class="slot got"><div class="art"><div class="stamp s-bonus" style="--r:4deg">${bonusStampHTML(b, b.name, false)}</div></div><span class="nm">${esc(b.name)} (day ${b.day})</span></div>`).join('');
    sections += `<h3 class="booksec"><span class="dot" style="background:${c.color};width:22px;height:22px;border-radius:50%;display:grid;place-items:center">${c.icon.replace('class="ico"', 'style="width:14px;height:14px"')}</span>${c.name} <span class="cnt">${got.length} collected</span></h3><div class="grid">${slots}</div>`;
  }
  const fe = BOOK.feats || {};
  const featSlots = FEATS.map(f => fe[f[0]] ? `<div class="slot got"><span class="ct">\u00d7${fe[f[0]].n}</span><div class="art"><div class="stamp s-bonus s-feat" style="--r:-4deg">${featHTML(f, false)}</div></div><span class="nm">${f[1]}</span></div>`
    : `<div class="slot locked" title="${f[2]}"><span class="q">?</span><span class="nm">${f[1]}</span></div>`).join('');
  sections += `<h3 class="booksec"><span class="dot" style="background:#1E6BFF;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:12px">\ud83c\udfc5</span>Climbing Feats <span class="cnt">${Object.keys(fe).length} of ${FEATS.length}</span></h3><p class="booksub" style="margin:-4px 0 8px">Earned by how you climb. Locked feats show their name, so you know what to chase.</p><div class="grid">${featSlots}</div>`;
  $('book').innerHTML = `<div class="bookcard" role="dialog" aria-label="Sticker book">
    <div class="bookhead"><h2>Sticker Book</h2><button id="closebook" class="quiet">Close</button></div>
    <p class="booksub">${totalToday} bonus stickers to find today. Found so far: ${gotToday} of ${totalToday}.</p>
    <h3 class="booksec">Climbing grades</h3><div class="grid grades">${tierSlots}</div>
    ${sections}</div>`;
  $('book').hidden = false;
  $('closebook').onclick = () => { $('book').hidden = true; };
  document.querySelectorAll('#book .slot').forEach(sl => sl.onclick = () => {
    const art = sl.querySelector('.art'), name = sl.querySelector('.nm').textContent, ct = sl.querySelector('.ct');
    const pv = document.createElement('div'); pv.className = 'bookpreview';
    pv.innerHTML = art ? `<div class="pvwrap">${art.innerHTML}</div><p class="pvcap">${esc(name)}${ct ? ' \u00b7 collected ' + ct.textContent : ''}<br><span>Tap anywhere to close</span></p>`
      : sl.dataset.hint ? `<div class="pvlocked">?</div><p class="pvcap">${esc(sl.dataset.q)}</p><p class="pvhint"><b>Hint</b>${esc(sl.dataset.hint)}</p><p class="pvcap"><span>Tap anywhere to close</span></p>`
      : `<div class="pvlocked">?</div><p class="pvcap">${esc(name)}<br>${sl.title ? esc(sl.title) : 'Not found yet'}<br><span>Tap anywhere to close</span></p>`;
    pv.onclick = () => pv.remove(); $('book').appendChild(pv); Sound.sticker();
  });
  $('closebook').focus();
}


/* ---------- Climbing feats (gameplay stickers, kept forever) ---------- */
const FEATS = [
  ['firstclimb', 'First Climb', 'Finish your first ascent', '\ud83e\uddd7', '#1E6BFF'],
  ['quick', 'Quick Draw', 'Answer in under 5 seconds', '\u26a1', '#6B3FE0'],
  ['lightning', 'Lightning Hands', 'Three answers under 5 seconds in one climb', '\ud83c\udf29\ufe0f', '#6B3FE0'],
  ['buzzer', 'Buzzer Beater', 'Answer with 1 second left', '\u23f1\ufe0f', '#6B3FE0'],
  ['gem', 'Gem Hunter', 'Find a First ascent', '\ud83d\udc8e', '#C98600'],
  ['triplegem', 'Treasure Trove', 'Find 3 First ascents in one climb', '\ud83d\udc51', '#C98600'],
  ['cleansweep', 'Clean Sweep', 'Finish a climb with no wrong answers', '\ud83e\uddf9', '#17A35C'],
  ['fulltank', 'Full Tank', 'Finish with 100% oxygen', '\ud83e\udee7', '#17A35C'],
  ['lastgasp', 'Last Gasp', 'Finish with 10% oxygen or less', '\ud83d\ude2e\u200d\ud83d\udca8', '#17A35C'],
  ['summit', 'Summiteer', 'Reach the summit of Everest', '\ud83c\udfd4\ufe0f', '#1E6BFF'],
  ['space', 'Astronaut', 'Reach space', '\ud83d\ude80', '#1E6BFF'],
  ['moon', 'Moonwalker', 'Reach the Moon', '\ud83c\udf15', '#1E6BFF'],
  ['aliens', 'Close Encounter', 'Reach alien territory', '\ud83d\udc7d', '#1E6BFF'],
  ['fogbound', 'Lost in the Fog', 'Hit 3 false summits in one climb', '\ud83c\udf2b\ufe0f', '#8E1420'],
  ['frozen', 'Frozen Solid', 'Let the clock run out', '\ud83e\udd76', '#8E1420'],
  ['freefall', 'Free Fall', 'Run out of oxygen', '\ud83e\ude82', '#8E1420']
];
const FEAT = Object.fromEntries(FEATS.map(f => [f[0], f]));
const medalSVG = f => `<svg viewBox="0 0 200 210"><path d="M58 0 H96 L110 92 L78 104 Z" fill="${f[4]}"/><path d="M142 0 H104 L90 92 L122 104 Z" fill="#FFC21A"/><path d="M58 0 H70 L86 100 L78 104 Z M130 0 H142 L122 104 L114 100 Z" fill="rgba(0,0,0,.18)"/><circle cx="100" cy="138" r="68" fill="#E39A00"/><circle cx="100" cy="138" r="58" fill="#FFD34D"/><circle cx="100" cy="138" r="46" fill="#fff" opacity=".35"/><text x="100" y="160" text-anchor="middle" font-size="62">${f[3]}</text></svg>`;
const featHTML = (f, isNew) => `<div class="bart">${medalSVG(f)}</div><div class="ribbon" style="--bc:${f[4]}"><small>CLIMBING FEAT</small><b>${f[1]}</b><i>${f[2]}</i></div>${isNew ? '<span class="new">NEW!</span>' : ''}`;
let featQueue = [], featTimer = null;
function award(id) {
  if (!BOOK.feats) BOOK.feats = {};
  const f = FEAT[id]; if (!f) return;
  const had = BOOK.feats[id];
  BOOK.feats[id] = { n: (had ? had.n : 0) + 1, day: had ? had.day : DAY.num };
  saveBook();
  if (!had) { featQueue.push(f); if (!featTimer) featTimer = setTimeout(nextFeat, 4300); }
}
function nextFeat() {
  const f = featQueue.shift(); if (!f) { featTimer = null; return; }
  Sound.sticker();
  const el = document.createElement('div');
  el.className = 'stamp s-bonus s-feat'; el.style.setProperty('--r', (Math.random() * 12 - 6).toFixed(1) + 'deg');
  el.innerHTML = featHTML(f, true);
  document.body.appendChild(el); setTimeout(() => el.remove(), 2700);
  featTimer = setTimeout(nextFeat, 2000);
}

/* ---------- Boot ---------- */
(function makeWeather() {
  let r = '', s = '';
  for (let i = 0; i < 110; i++) r += `<span class="drop" style="left:${(Math.random() * 135).toFixed(1)}%;--d:${(.55 + Math.random() * .5).toFixed(2)}s;--dl:-${(Math.random() * 2).toFixed(2)}s"></span>`;
  for (let i = 0; i < 70; i++) { const z = (2 + Math.random() * 3).toFixed(1); s += `<span class="flake" style="left:${(Math.random() * 140).toFixed(1)}%;--s:${z}px;--d:${(1.4 + Math.random() * 1.6).toFixed(2)}s;--dl:-${(Math.random() * 3).toFixed(2)}s"></span>`; }
  $('rain').innerHTML = r; $('snowfx').innerHTML = s;
})();
document.querySelectorAll('.sndbtn').forEach(b => { b.innerHTML = Sound.icon(); b.onclick = e => { e.stopPropagation(); Sound.init(); Sound.setMuted(!Sound.muted); }; });
buildWorld();
paintBest();
paintWorld(S.lift);
render();
if (S.outOfAir) startFall();
